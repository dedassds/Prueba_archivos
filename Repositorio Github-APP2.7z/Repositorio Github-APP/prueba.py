import sys

from PyQt5 import QtGui
from PyQt5 import QtWidgets

from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

def main():
    app = QtWidgets.QApplication(sys.argv)
    programWindow = ProgramWindow()

    programWindow.show()
    sys.exit(app.exec_())


class ProgramWindow(QtWidgets.QMainWindow):

    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.setup_main_window()

        self.first_input_text()
        self.second_input_text()

        self.set_window_layout()

    def setup_main_window(self):
        self.resize( 800, 600 )
        self.centralwidget = QWidget()
        self.setCentralWidget( self.centralwidget )

    def first_input_text(self):
        self.textEditWidget1 = QPlainTextEdit( self )
        self.startSimulationButton1 = QPushButton( "Start Simulation" )
        self.startSimulationButton1.setMinimumWidth(150) #+
        #self.startSimulationButtonDumb = QPushButton( "Start Simulation fillingg" )

        verticalInnerLayout = QVBoxLayout()
        verticalInnerLayout.addWidget( self.startSimulationButton1 )
        #verticalInnerLayout.addWidget( self.startSimulationButtonDumb )

        horizontalInnerLayout = QHBoxLayout()
        horizontalInnerLayout.addLayout( verticalInnerLayout )
        horizontalInnerLayout.addWidget( self.textEditWidget1 )

        self.groupBox1 = QGroupBox( "First Group" )
        self.groupBox1.setLayout( horizontalInnerLayout )

    def second_input_text(self):
        self.textEditWidget2 = QPlainTextEdit( self )
        self.startSimulationButton2 = QPushButton( "Start Simulation bigger" )
        self.startSimulationButton2.setMinimumWidth(150) # +

        verticalInnerLayout = QVBoxLayout()
        verticalInnerLayout.addWidget( self.startSimulationButton2 )

        horizontalInnerLayout = QHBoxLayout()
        horizontalInnerLayout.addLayout( verticalInnerLayout )
        horizontalInnerLayout.addWidget( self.textEditWidget2 )

        self.groupBox2 = QGroupBox( "Second Group" )
        self.groupBox2.setLayout( horizontalInnerLayout )

    def set_window_layout(self):
        main_vertical_layout = QVBoxLayout( self.centralwidget )
        main_vertical_layout.addWidget( self.groupBox1 )
        main_vertical_layout.addWidget( self.groupBox2 )


if __name__ == "__main__":
    main()