import os
import sys
import subprocess
import git
from PyQt5.QtWidgets import ( QApplication, QMainWindow, QTextEdit, QVBoxLayout, QPushButton, QWidget, QLabel, QLineEdit, QPlainTextEdit, QDialog,
 QFileDialog, QMessageBox, QInputDialog, QGridLayout, QSplitter, QTreeView, QFileSystemModel, QHBoxLayout,
 QApplication, QMainWindow, QTableWidget, QTableWidgetItem)

from PyQt5.QtCore import Qt
import tkinter as tk
from tkinter import filedialog, messagebox
from ldap3 import Server, Connection, ALL, SUBTREE
from PyQt5.QtWidgets import QComboBox
from datetime import datetime
from PyQt5.QtGui import QFont, QIcon, QPixmap

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


# Variable de bandera para el inicio de sesión exitoso
login_successful = False

#Variables de las rutas tanto master como el local
ruta1 = "C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Master\\Programa_2\\Repositorio Github-APP"
ruta2 ="C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Programa_2\\Repositorio Github-APP"

class VisualizadorTabla(QMainWindow):
    def __init__(self):
        super().__init__()

         # Datos de ejemplo para la tabla (puedes reemplazarlos con tus propios datos)
        data = [
            ["Nombre", "Edad", "País"],
            ["Alice", "25", "EE. UU."],
            ["Bob", "30", "Canadá"],
            ["Charlie", "28", "Reino Unido"],
        ]
        self.data = data
        self.iniciarUI()

    def iniciarUI(self):
        self.setWindowTitle('Visualizador de Datos')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Crear una tabla para mostrar los datos
        tabla = QTableWidget()
        tabla.setColumnCount(len(self.data[0]))
        tabla.setRowCount(len(self.data))

        # Agregar los datos a la tabla
        for fila, datos_fila in enumerate(self.data):
            for columna, valor in enumerate(datos_fila):
                item = QTableWidgetItem(str(valor))
                tabla.setItem(fila, columna, item)

        # Configurar encabezados de columnas
        encabezados = self.data[0]
        tabla.setHorizontalHeaderLabels(encabezados)

        # Ajustar el tamaño de las columnas para que se ajusten al contenido
        tabla.resizeColumnsToContents()

        layout = QVBoxLayout()
        layout.addWidget(tabla)
        central_widget.setLayout(layout)

class GitViewer(QMainWindow):

    def __init__(self, username=None):
        super().__init__()
        self.username = username
        self.initUI()

        # Crear una instancia de VisualizadorTabla (aún no se muestra)
        self.ventana_tabla = VisualizadorTabla()
    
    def mostrar_tabla(self):
        # Mostrar la instancia de VisualizadorTabla cuando sea necesario
        self.ventana_tabla.show()
    
    def detectar_rama(self):
        try:
            resultado = subprocess.run(['git', 'branch', '--show-current'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al detectar la rama actual: {str(e)}")
            return "Rama Desconocida"
    
    def setup_watchdog(self):
        event_handler = FileModifiedHandler(self)
        observer = Observer()
        observer.schedule(event_handler, ruta1, recursive=True)
        observer.schedule(event_handler, ruta2, recursive=True)
        observer.start()
     
    
    def obtener_rama_actual(self):
        try:
            resultado = subprocess.run(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al obtener la rama actual: {str(e)}")
            return "Rama Desconocida"

    def registrar_accion(self, accion):
        username = self.username
        fecha = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        accion_registrada = f"{username} {accion} en la rama {self.detectar_rama()} a las {fecha}\n"
        
        # Comprueba si el archivo 'acciones.log' existe, y si no, lo crea
        if not os.path.exists('acciones.log'):
            with open('acciones.log', 'w') as archivo_log:
                archivo_log.write(accion_registrada)
        else:
            with open('acciones.log', 'a') as archivo_log:
                archivo_log.write(accion_registrada)
    
    def actualizar_remoto(self):
        try:
            # Detecta la rama actual
            rama_actual = self.obtener_rama_actual()
            
            # Configura la rama remota si no está configurada
            subprocess.run(["git", "push", "--set-upstream", "origin", rama_actual])
            
            # Ejecuta el comando 'git push' para subir los cambios al repositorio remoto
            subprocess.run(["git", "push"])
            
            # Registra la acción en el historial
            self.registrar_accion(f"actualizó el repositorio remoto de la rama {rama_actual}")
            
            # Muestra un mensaje de éxito
            QMessageBox.information(self, "Actualización Remota", "Los cambios se han actualizado en el repositorio remoto.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al actualizar el repositorio remoto: {str(e)}")

    

    def git_add_commit_push(self, mensaje_commit, ruta1, ruta2):
    #def git_add_commit_push(self, mensaje_commit):
        try:
            
            # Verificar si ambas rutas terminan en la misma carpeta
            if os.path.basename(os.path.normpath(ruta1)) == os.path.basename(os.path.normpath(ruta2)):
                # Ambas rutas terminan en la misma carpeta, proceder con commit y push en ambas rutas

                # Cambiar el directorio de trabajo a la primera ruta
                os.chdir(ruta1)

                # Agregar los cambios
                subprocess.run(['git', 'add', '.'])

                # Hacer el commit
                subprocess.run(['git', 'commit', '-m', mensaje_commit])

                # Realizar el pull
                subprocess.run(['git', 'pull'])

                # Realizar el push
                subprocess.run(['git', 'push'])

                # Cambiar el directorio de trabajo de vuelta a la segunda ruta
                os.chdir(ruta2)

                # Agregar los cambios
                subprocess.run(['git', 'add', '.'])

                # Hacer el commit
                subprocess.run(['git', 'commit', '-m', mensaje_commit])

                # Realizar el pull
                subprocess.run(['git', 'pull'])

                # Realizar el push
                subprocess.run(['git', 'push'])

                # Registra la acción en el historial
                # self.registrar_accion(f'realizó un commit con el mensaje: "{mensaje_commit}"')

                # Muestra un mensaje de éxito
                QMessageBox.information(self, "Commit y Push", "Los cambios se han commiteado y enviado al repositorio remoto en ambas rutas.")
            else:
                # Las rutas no terminan en la misma carpeta
                QMessageBox.warning(self, "Advertencia", "Las rutas no terminan en la misma carpeta. No se pueden realizar commit y push.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al hacer commit y push: {str(e)}")

        
    
    "resolver rutas"
    @classmethod #de esta manera lo defines como metodo de clase
    def resource_path(cls, relative_path):
        

        # Get absolute path to resource, works for dev and for PyInstaller 
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")

        return os.path.join(base_path, relative_path)

    def initUI(self):
        self.setWindowTitle('Visualizador de Git')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Crear un splitter para dividir la ventana en tres secciones
        splitter = QSplitter()

        # Crear tres frames para cada sección
        top_frame = QWidget()
        left_frame = QWidget()
        right_frame = QWidget()

        # Configurar el splitter para dividir horizontalmente
        splitter.setOrientation(Qt.Horizontal)  # Utiliza 'Qt.Horizontal' en lugar de 1

        # Agregar los frames al splitter
        splitter.addWidget(top_frame)
        splitter.addWidget(left_frame)
        splitter.addWidget(right_frame)

        # Configurar el tamaño inicial de los frames
        splitter.setSizes([400, 100, 500])
       
        # Crear un layout vertical para el frame superior
        #top_layout = QHBoxLayout() #Oorganiza los widgets de manera horizontal
        top_layout = QVBoxLayout()
        
        # Establece los márgenes alrededor de top_layout
        top_layout.setContentsMargins(0, 0, 0, 0)  # Ajusta los valores según tus preferencias

        # Establece el espacio entre widgets dentro de top_layout
        top_layout.setSpacing(0)  # Ajusta el valor según tus preferencias
        

        # Establecer el splitter como widget central
        central_layout = QVBoxLayout()  # Crea un layout vertical para el widget central
        central_layout.addWidget(splitter)  # Agrega el splitter al layout central
        
        #Este elemento me indica como se va dividir la pantalla principal
        #central_widget.setLayout(central_layout)  # Establece el layout central en el widget central

         # Crear un layout de cuadrícula para organizar los tres frames
        grid_layout = QGridLayout()
        central_widget.setLayout(grid_layout)  # Establecer el layout de la ventana principal
  
        #grid_layout = QGridLayout()
        grid_layout.addWidget(top_frame, 0, 0, 1, 2)  # Frame superior ocupa dos columnas
        grid_layout.addWidget(left_frame, 1, 0)       # Frame izquierdo en la fila 1, columna 0
        grid_layout.addWidget(right_frame, 1, 1)      # Frame derecho en la fila 1, columna 1
        

        # Crear un layout de cuadrícula
        layout = QGridLayout()

        # Crear un layout vertical para el frame izquierdo
        left_layout = QVBoxLayout()

        # Crear un modelo de sistema de archivos para la vista de árbol
        model = QFileSystemModel()
        model.setRootPath('')
        model.setReadOnly(True)

        # Crear una vista de árbol para mostrar el contenido del directorio
        tree_view = QTreeView()
        tree_view.setModel(model)
        #tree_view.setRootIndex(model.index(os.path.expanduser('~')))  # Establece la carpeta de inicio

        #Establece la ruta especializada para el tree_view
        ruta_personalizada = "C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Programa_2\\Repositorio Github-APP"
        tree_view.setRootIndex(model.index(ruta_personalizada))


        # Establecer el ancho mínimo preferido del QTreeView
        tree_view.setMinimumWidth(500)

        self.cambios_label = QLabel('Cambios en el Repositorio:')
        self.cambios_label.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente
        #layout.addWidget(self.cambios_label)

        self.cambios_output = QTextEdit()
        self.cambios_output.setReadOnly(True)
        #layout.addWidget(self.cambios_output)

        self.mostrar_cambios_button = QPushButton('Mostrar Cambios')
        self.mostrar_cambios_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.mostrar_cambios_button.clicked.connect(self.mostrar_cambios)
        #layout.addWidget(self.mostrar_cambios_button)

        # Botón para revertir cambios
        self.revertir_cambios_button = QPushButton('Revertir Cambios')
        self.revertir_cambios_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.revertir_cambios_button.clicked.connect(self.revertir_cambios)
        #layout.addWidget(self.revertir_cambios_button)

        # Boton actualizar repositorio
        self.actualizar_remoto_button = QPushButton('Actualizar Repositorio Remoto')
        self.actualizar_remoto_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.actualizar_remoto_button.clicked.connect(self.actualizar_remoto)
        #layout.addWidget(self.actualizar_remoto_button)

        # Agregar un label a la ventana principal
        self.branch_label = QLabel('Usuario conectado:')
        self.branch_label.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente
        #layout.addWidget(self.branch_label)

        # Nuevo campo de entrada para mostrar el nombre de usuario
        self.usuario_entry = QLineEdit()
        self.usuario_entry.setPlaceholderText('Usuario')
        self.usuario_entry.setReadOnly(True)
        self.usuario_entry.setText(self.username)  # Establecer el nombre de usuario aquí
        self.usuario_entry.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        #layout.addWidget(self.usuario_entry)

        #------Botones para eliminar ----------    

        # Agregar un label a la ventana principal
        self.branch_label = QLabel('Seleccionar Commit:')
        self.branch_label.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente
        #layout.addWidget(self.branch_label)

        # Agregar un combo box para seleccionar el commit a revertir
        self.commit_combobox = QComboBox()
        #layout.addWidget(self.commit_combobox)

        # Agregar un label a la ventana principal
        self.branch_label = QLabel('Seleccionar Rama:')
        self.branch_label.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente
        #layout.addWidget(self.branch_label)

        # Agregar un combo box para seleccionar las ramas
        self.branch_combobox = QComboBox()
        self.detectar_ramas_disponibles()
        #layout.addWidget(self.branch_combobox)

        # Agregar un botón para actualizar la vista según la rama seleccionada
        self.actualizar_button = QPushButton('Actualizar Vista')
        self.actualizar_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.actualizar_button.clicked.connect(self.actualizar_vista)
        #layout.addWidget(self.actualizar_button)

        # Agregar un botón para actualizar la vista según los commits
        self.actualizar_button_commit = QPushButton('Actualizar Lista Commits')
        self.actualizar_button_commit.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.actualizar_button_commit.clicked.connect(self.actualizar_vista_commit)
        #layout.addWidget(self.actualizar_button_commit)

        self.mostrar_historial_button = QPushButton('Mostrar Historial')
        self.mostrar_historial_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.mostrar_historial_button.clicked.connect(self.mostrar_historial)
        #layout.addWidget(self.mostrar_historial_button)

        # Botón para realizar commit y push
        self.commit_push_button = QPushButton('Commit y Push')
        self.commit_push_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.commit_push_button.clicked.connect(self.hacer_commit_y_push)
        #layout.addWidget(self.commit_push_button)

        #-------------------------Frame Top ------------------------------
        #widgets
        self.usuario_label = QLabel('')
        self.usuario_label.setFont(QFont('Segoe UI', 14)) 
  
        self.usuario_label_login = QLabel('')
        self.usuario_label_login.setFont(QFont('Segoe UI', 14))
        self.usuario_label_login.setText(self.username)

        self.usuario_espacio = QLabel('Repositorio Master - visualizador ')
        self.usuario_espacio.setFont(QFont('Segoe UI', 14)) 
        # Establece el ancho del QLabel utilizando setFixedWidth (por ejemplo, 20 píxeles)
        #self.usuario_espacio.setFixedWidth(5)

        self.terminal_top = QTextEdit()
        self.terminal_top.setReadOnly(True)
        #layout.addWidget(self.terminal_top)

        #modificar margenes
        self.usuario_label.setContentsMargins(0, 0, 0, 0)  # Establece los márgenes en cero
        self.usuario_label_login.setContentsMargins(0, 0, 0, 0)  # Establece los márgenes en cero


        # Crear un botón de prueba
        self.boton_prueba = QPushButton('Botón de Prueba')
        self.boton_prueba.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.boton_prueba.setMinimumWidth(50)  # Establece el ancho mínimo
        self.boton_prueba.setMaximumWidth(100)  # Establece el ancho máximo

        #-----------------tree_view top frame--------------------------

        # Crear un modelo de sistema de archivos para la vista de árbol
        model_2 = QFileSystemModel()
        model_2.setRootPath('')
        model_2.setReadOnly(True)

        # Crear una vista de árbol para mostrar el contenido del directorio
        tree_view_2 = QTreeView()
        tree_view_2.setModel(model)
        #tree_view.setRootIndex(model.index(os.path.expanduser('~')))  # Establece la carpeta de inicio

        #Establece la ruta especializada para el tree_view
        ruta_personalizada_2 = "C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Master"
        tree_view_2.setRootIndex(model.index(ruta_personalizada_2))


        # Establecer el ancho mínimo preferido del QTreeView
        #tree_view_2.setMinimumWidth(500,300)

        #Establecer el ancho maximo
        #tree_view_2.setMaximumWidth(600,600)

        tree_view_2.setMinimumSize(500, 200)
        tree_view_2.setMaximumSize(1000, 350)


        #--------imagen usuario ------------

        # Carga la imagen utilizando resource_path
        imagen_path = self.resource_path('imagenes/user.png')
        pixmap = QPixmap(imagen_path)
        pixmap = pixmap.scaled(50, 50)
        self.usuario_label.setPixmap(pixmap)

        #-------imagen logo flex -----------

        # Carga la imagen utilizando resource_path
        #imagen_path_2 = self.resource_path('imagenes/flex_loga.png')
        #pixmap_2 = QPixmap(imagen_path_2)
        #pixmap_2 = pixmap_2.scaled(100, 100)
        #self.usuario_espacio.setPixmap(pixmap_2)

        #-------------posicionamiento widgets right frame --------

        # Agregar widgets a la cuadrícula en celdas específicas
        #layout.addWidget(self.archivos_label, 0, 0, 1, 2)  # (widget, row, column, rowspan, columnspan)
        #layout.addWidget(self.archivos_output, 1, 0, 1, 2)
        #layout.addWidget(self.mostrar_archivos_button, 2, 0, 1, 2)
        layout.addWidget(self.cambios_label, 3, 0, 1, 2)
        layout.addWidget(self.cambios_output, 4, 0, 1, 2)
        layout.addWidget(self.mostrar_cambios_button, 5, 0, 1, 2)
        layout.addWidget(self.revertir_cambios_button, 6, 0, 1, 2)
        #layout.addWidget(self.actualizar_remoto_button, 7, 0, 1, 2)
        layout.addWidget(self.commit_combobox, 7, 0, 1, 2)   
        layout.addWidget(self.branch_label, 8, 0, 1, 1)
        layout.addWidget(self.usuario_entry, 8, 1, 1, 1)
        #layout.addWidget(self.eliminar_archivo_button, 9, 0, 1, 2)
        #layout.addWidget(self.modificar_archivo_button, 10, 0, 1, 2)
        layout.addWidget(self.branch_label, 11, 0, 1, 1)
        layout.addWidget(self.branch_combobox, 11, 1, 1, 1)
        layout.addWidget(self.actualizar_button, 12, 0, 1, 2)
        layout.addWidget(self.actualizar_button_commit, 13, 0, 1, 2)
        layout.addWidget(self.mostrar_historial_button, 14, 0, 1, 2)
        layout.addWidget(self.commit_push_button, 15, 0, 1, 2)

        #------- posicionamiento widgets top frame ---------

        top_layout.addWidget(self.usuario_label)
        top_layout.addWidget( self.usuario_espacio, alignment=Qt.AlignTop | Qt.AlignCenter)
        top_layout.addWidget( self.usuario_label_login)
        
        #top_layout.addWidget(self.boton_prueba)
        #top_layout.addWidget( self.terminal_top)
        top_layout.addWidget(tree_view_2)

        #-------posicionamiento widgets left frame ---------

        left_layout.addWidget(tree_view)
        

        #------ carga de layouts a sus respectivos frames -----

        #central_widget.setLayout(layout)

        # Establecer el layout en el frame superior
        top_frame.setLayout(top_layout)  

        # Establecer el layout en el frame izquierdo
        left_frame.setLayout(left_layout)

        # Asignar el layout al frame derecho
        right_frame.setLayout(layout)
    
    def revertir_cambios(self):
        selected_branch = self.branch_combobox.currentText()
        selected_commit = self.commit_combobox.currentText()

        if not selected_commit:
            QMessageBox.warning(self, "Advertencia", "Por favor, seleccione un commit para revertir.")
            return

        try:
            repo = git.Repo('.')
            # Cambiar a la rama seleccionada
            repo.git.checkout(selected_branch)

            # Obtener el hash del commit a partir del texto seleccionado
            with open('versiones.log', 'r') as version_log:
                commit_hash = None
                for line in version_log:
                    if selected_commit in line:
                        commit_hash = line.split('-')[1].strip()
                        break

            if commit_hash is None:
                QMessageBox.warning(self, "Advertencia", "No se pudo encontrar el hash del commit en versiones.log.")
                return

            # Utilizar git revert para deshacer completamente el commit seleccionado
            repo.git.revert("-n", commit_hash)  # -n para no hacer commit automático

            # Mostrar los cambios pendientes en un nuevo commit
            subprocess.run(["git", "status"], capture_output=True, text=True, shell=True)

            # Registrar la acción en el historial
            self.registrar_accion(f'revirtió completamente el commit {commit_hash} en la rama {selected_branch}')
            
            QMessageBox.information(self, "Revertir Cambios", f"El commit {commit_hash} se ha revertido completamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al revertir cambios: {str(e)}")


    def mostrar_archivos(self):
        if sys.platform == 'win32':
            comando = ['dir']
        else:
            comando = ['ls']

        resultado = subprocess.run(comando, capture_output=True, text=True, shell=True)
        self.archivos_output.setPlainText(resultado.stdout)

    def mostrar_cambios(self):
        resultado = subprocess.run(['git', 'status'], capture_output=True, text=True, shell=True)
        self.cambios_output.setPlainText(resultado.stdout)
        self.ventana_tabla.show()

    def detectar_ramas_disponibles(self):
        repo = git.Repo('.')
        ramas = [str(branch) for branch in repo.branches]
        self.branch_combobox.addItems(ramas)

    def actualizar_vista(self):
        selected_branch = self.branch_combobox.currentText()
        repo = git.Repo('.')
        repo.git.checkout(selected_branch)
        messagebox.showinfo('Actualizado', f'Se cambió a la rama: {selected_branch}')
        self.mostrar_cambios()
    
    def actualizar_vista_commit(self):
        selected_branch = self.branch_combobox.currentText()
        repo = git.Repo('.')
        repo.git.checkout(selected_branch)
        self.mostrar_commits()  # Llama a mostrar_commits para llenar el combo box
        #self.git_add_commit_push("Commit forzado")

# ...

    def mostrar_commits(self):
        try:
            selected_branch = self.branch_combobox.currentText()
            repo = git.Repo('.')
            repo.git.checkout(selected_branch)
            commits = [(commit.hexsha, commit.message, commit.author.name, commit.committed_datetime) for commit in reversed(list(repo.iter_commits(selected_branch)))]

            # Invierte la lista de commits para mostrarlos en orden descendente
            commits.reverse()

            self.commit_combobox.clear()
            self.commit_combobox.addItem('Seleccionar Commit')  # Opción inicial

            # Calcula el número total de commits en la rama
            total_commits = len(commits)

            # Eliminar el archivo versiones.log si ya existe
            if os.path.exists('versiones.log'):
                os.remove('versiones.log')

            # Agregar encabezados al archivo versiones.log
            with open('versiones.log', 'a') as version_log:
                version_log.write("Versiones - Numero de Commit - Responsable - Fecha\n")

            # Recorre los commits y asigna versiones en orden descendente
            version = total_commits
            for commit_hash, commit_message, author_name, committed_datetime in commits:
                version_str = f'Version {version}.0.0'
                # Agregar el commit al archivo versiones.log
                with open('versiones.log', 'a') as version_log:
                    version_log.write(f'{version_str} - {commit_hash} - {self.username} - {committed_datetime}\n')
                self.commit_combobox.addItem(f'{version_str} - {commit_message}')
                version -= 1
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al obtener commits: {str(e)}")



    def mostrar_historial(self):
        try:
            with open('acciones.log', 'r') as archivo_log:
                historial = archivo_log.read()
                if historial.strip():  # Verifica si el historial no está vacío
                    historial_dialog = QDialog(self)
                    historial_dialog.setWindowTitle('Historial de Acciones')
                    historial_dialog.setGeometry(200, 200, 600, 400)

                    layout = QVBoxLayout()

                    historial_text = QPlainTextEdit()
                    historial_text.setReadOnly(True)
                    historial_text.setPlainText(historial)

                    layout.addWidget(historial_text)
                    historial_dialog.setLayout(layout)
                    historial_dialog.exec_()
                else:
                    print("El archivo de historial está vacío.")
        except FileNotFoundError:
            # Si el archivo no existe, muestra un mensaje
            print("El archivo de historial aún no ha sido creado.")

    def hacer_commit_y_push(self):
        mensaje_commit, ok = QInputDialog.getText(self, 'Mensaje de Commit', 'Por favor, ingresa el mensaje de commit:')
        if ok:
            self.git_add_commit_push(mensaje_commit,ruta1,ruta2)

# Nueva clase para manejar eventos de modificación de archivos con Watchdog
class FileModifiedHandler(FileSystemEventHandler):
    def __init__(self, git_viewer):
        self.git_viewer = git_viewer

    def on_modified(self, event):
        if event.is_directory:
            return
        if event.src_path.startswith(ruta1):
            self.sync_folders(ruta1, ruta2)
        elif event.src_path.startswith(ruta2):
            self.sync_folders(ruta2, ruta1)

    def sync_folders(self, src, dest):
        # Implementa la lógica de sincronización de carpetas aquí
        pass
class LoginWindow_supervisor(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.master.wm_geometry("400x225")
        self['bg'] = '#FFFFFF'
        self.container = tk.Frame(self)
        self.container['bg'] = "#FFFFFF"
        self.container.pack(fill='both', expand=1)
        self._create_widgets()
        self._place_widgets()

    def _create_widgets(self):
        self.user_label = tk.Label(self.container, text='User', font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.user_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
        )
        self.pass_label = tk.Label(self.container, text="Password", font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.pass_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
            show="*",
        )
        self.login_button = tk.Button(
            self.container,
            text='Login',
            font=('Segoe UI', 15),
            fg="#FFFFFF",
            bd=0,
            bg="#005486",
            highlightthickness=0,
            highlightbackground="#FFFFFF",
            activebackground="#009add",
            width=30,
            command=self.log_user_in
        )

    def _place_widgets(self):
        self.user_label.pack()
        self.user_entry.pack()
        self.pass_label.pack()
        self.pass_entry.pack()
        self.login_button.pack(pady=10)

    def log_user_in(self):
        global login_successful
        user = self.user_entry.get()
        password = self.pass_entry.get()
        domain = "nico.com"
        server = Server('5', use_ssl=True, get_info=ALL)
        full_user = user + '@' + domain
        try:
            conn = Connection(server, full_user, password, auto_bind=True)
        except Exception as e:
            messagebox.showerror(title='Error', message=str(e))
        else:
            conn.search(search_base='nico=com',
                         search_filter=f"""(&(objectClass=user)(sAMAccountname={user}))""",
                         search_scope=SUBTREE,
                         attributes=['displayname', 'title', 'sAMAccountname', 'employeeNumber', 'mail', 'personaltitle'])
            for entry in conn.response:
                attributes = entry['attributes']
            if attributes.get('title') in ['Debug Technician', 'Student'] or attributes.get('employeeNumber') == 'WD911888':
                login_successful = True
                self.master.destroy()
                self.show_next_station(user)

    def show_next_station(self, username):
        if login_successful:
            app = QApplication(sys.argv)
            window = GitViewer(username=username)
            window.setup_watchdog()  # Iniciar Watchdog
            window.show()
            sys.exit(app.exec_())

def main():
    #comentar para deshabilitar login
    #root = tk.Tk()
    #root.title("Aplicación")
    #login_window = LoginWindow_supervisor(root)
    #login_window.pack(side='left', fill='both', expand=1)
    #root.mainloop()

    #descomentar para iniciar directamente

    app = QApplication(sys.argv)

    # Crear una instancia de GitViewer y mostrarla

    window = GitViewer()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()




