import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QVBoxLayout, QPushButton, QWidget, QLabel

class GitViewer(QMainWindow):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Visualizador de Git')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()

        self.archivos_label = QLabel('Archivos en el Directorio:')
        layout.addWidget(self.archivos_label)

        self.archivos_output = QTextEdit()
        self.archivos_output.setReadOnly(True)
        layout.addWidget(self.archivos_output)

        self.mostrar_archivos_button = QPushButton('Mostrar Archivos')
        self.mostrar_archivos_button.clicked.connect(self.mostrar_archivos)
        layout.addWidget(self.mostrar_archivos_button)

        self.cambios_label = QLabel('Cambios en el Repositorio:')
        layout.addWidget(self.cambios_label)

        self.cambios_output = QTextEdit()
        self.cambios_output.setReadOnly(True)
        layout.addWidget(self.cambios_output)

        self.mostrar_cambios_button = QPushButton('Mostrar Cambios')
        self.mostrar_cambios_button.clicked.connect(self.mostrar_cambios)
        layout.addWidget(self.mostrar_cambios_button)

        central_widget.setLayout(layout)

    def mostrar_archivos(self):
        if sys.platform == 'win32':
            comando = ['dir']
        else:
            comando = ['ls']

        resultado = subprocess.run(comando, capture_output=True, text=True, shell=True)
        self.archivos_output.setPlainText(resultado.stdout)

    def mostrar_cambios(self):
        resultado = subprocess.run(['git', 'status'], capture_output=True, text=True, shell=True)
        self.cambios_output.setPlainText(resultado.stdout)

def main():
    app = QApplication(sys.argv)
    window = GitViewer()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
