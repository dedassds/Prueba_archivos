import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QVBoxLayout, QPushButton, QWidget, QLabel
import tkinter as tk
from tkinter import messagebox
from ldap3 import Server, Connection, ALL, SUBTREE

class GitViewer(QMainWindow):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Visualizador de Git')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()

        self.archivos_label = QLabel('Archivos en el Directorio:')
        layout.addWidget(self.archivos_label)

        self.archivos_output = QTextEdit()
        self.archivos_output.setReadOnly(True)
        layout.addWidget(self.archivos_output)

        self.mostrar_archivos_button = QPushButton('Mostrar Archivos')
        self.mostrar_archivos_button.clicked.connect(self.mostrar_archivos)
        layout.addWidget(self.mostrar_archivos_button)

        self.cambios_label = QLabel('Cambios en el Repositorio:')
        layout.addWidget(self.cambios_label)

        self.cambios_output = QTextEdit()
        self.cambios_output.setReadOnly(True)
        layout.addWidget(self.cambios_output)

        self.mostrar_cambios_button = QPushButton('Mostrar Cambios')
        self.mostrar_cambios_button.clicked.connect(self.mostrar_cambios)
        layout.addWidget(self.mostrar_cambios_button)

        central_widget.setLayout(layout)

    def mostrar_archivos(self):
        if sys.platform == 'win32':
            comando = ['dir']
        else:
            comando = ['ls']

        resultado = subprocess.run(comando, capture_output=True, text=True, shell=True)
        self.archivos_output.setPlainText(resultado.stdout)

    def mostrar_cambios(self):
        resultado = subprocess.run(['git', 'status'], capture_output=True, text=True, shell=True)
        self.cambios_output.setPlainText(resultado.stdout)


class LoginWindow_supervisor(tk.Frame):
    def __init__(self, master, next_station_class):
        super().__init__(master)
        self.master = master
        self.next_station_class = next_station_class
        self.master.wm_geometry("400x225")
        self['bg'] = '#202020'
        self.container = tk.Frame(self)
        self.container['bg'] = "#000000"
        self.controller = tk.BooleanVar()
        self.container.pack(fill='both', expand=1)
        self._create_widgets()
        self._place_widgets()

    def _create_widgets(self):
        self.user_label = tk.Label(self.container, text='User', font=('Segoe UI', 15), fg="#005486", bg="#000000")
        self.user_entry = tk.Entry(
                self.container,
                width=30,
                bg="#000000",
                fg="#FFFFFF",
                bd=0,
                highlightthickness=1,
                highlightbackground="#009ADD",
                font=('Segoe UI Semilight', 12),
                justify='center',
            )
        self.pass_label = tk.Label(self.container, text="Password", font=('Segoe UI', 15), fg="#005486", bg="#000000")
        self.pass_entry = tk.Entry(
                self.container,
                width=30,
                bg="#000000",
                fg="#FFFFFF",
                bd=0,
                highlightthickness=1,
                highlightbackground="#009ADD",
                font=('Segoe UI Semilight', 12),
                justify='center',
                show="*",
            )
        self.login_button = tk.Button(
            self.container,
            text='Login',
            font=('Segoe UI', 15),
            fg="#FFFFFF",
            bd=0,
            bg="#005486",
            highlightthickness=0,
            highlightbackground="#FFFFFF",
            activebackground="#009add",
            width=30,
            command=self.log_user_in
        )

    def _place_widgets(self):
        self.user_label.pack()
        self.user_entry.pack()
        self.pass_label.pack()
        self.pass_entry.pack()
        self.login_button.pack(pady=10)

    def log_user_in(self):
        user = self.user_entry.get()
        password = self.pass_entry.get()
        domain = "americas.ad.flextronics.com"
        server = Server('10.10.28.70', use_ssl=True, get_info=ALL)
        full_user = user + '@' + domain
        try:
            conn = Connection(server, full_user, password, auto_bind=True)
        except Exception as e:
            messagebox.showerror(title='Error', message=str(e))
        else:
            conn.search(search_base='ou=users,ou=gdl,ou=mx,dc=americas,dc=ad,dc=flextronics,dc=com',
                         search_filter=f"""(&(objectClass=user)(sAMAccountname={user}))""",
                         search_scope=SUBTREE,
                         attributes=['displayname', 'title', 'sAMAccountname', 'employeeNumber', 'mail', 'personaltitle'])
            for entry in conn.response:
                attributes = entry['attributes']
            if attributes.get('title') in ['Debug Technician', 'Student'] or attributes.get('employeeNumber') == 'W':
                self.controller.set(True)
                self.destroy()  # Cerrar la ventana de inicio de sesión
                self.show_next_station()

    def show_next_station(self):
        if self.next_station_class:
            app = QApplication(sys.argv)
            window = GitViewer()
            window.show()
            sys.exit(app.exec_())

def main():
    root = tk.Tk()
    root.title("Aplicación")
    login_window = LoginWindow_supervisor(root, next_station_class=GitViewer)
    login_window.pack(side='left', fill='both', expand=1)
    root.mainloop()

if __name__ == '__main__':
    main()
