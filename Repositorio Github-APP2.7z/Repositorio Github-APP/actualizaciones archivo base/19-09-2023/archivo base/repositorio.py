import os
import sys
import subprocess
import git
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QVBoxLayout, QPushButton, QWidget, QLabel, QLineEdit, QPlainTextEdit, QDialog, QFileDialog, QMessageBox, QInputDialog
import tkinter as tk
from tkinter import filedialog, messagebox
from ldap3 import Server, Connection, ALL, SUBTREE
from PyQt5.QtWidgets import QComboBox
from datetime import datetime

# Variable de bandera para el inicio de sesión exitoso
login_successful = False

class GitViewer(QMainWindow):
    def __init__(self, username=None):
        super().__init__()
        self.username = username
        self.initUI()
    
    def detectar_rama(self):
        try:
            resultado = subprocess.run(['git', 'branch', '--show-current'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al detectar la rama actual: {str(e)}")
            return "Rama Desconocida"
    
    def obtener_rama_actual(self):
        try:
            resultado = subprocess.run(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al obtener la rama actual: {str(e)}")
            return "Rama Desconocida"

    def registrar_accion(self, accion):
        username = self.username
        fecha = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        accion_registrada = f"{username} {accion} en la rama {self.detectar_rama()} a las {fecha}\n"
        
        # Comprueba si el archivo 'acciones.log' existe, y si no, lo crea
        if not os.path.exists('acciones.log'):
            with open('acciones.log', 'w') as archivo_log:
                archivo_log.write(accion_registrada)
        else:
            with open('acciones.log', 'a') as archivo_log:
                archivo_log.write(accion_registrada)
    
    def actualizar_remoto(self):
        try:
            # Detecta la rama actual
            rama_actual = self.obtener_rama_actual()
            
            # Configura la rama remota si no está configurada
            subprocess.run(["git", "push", "--set-upstream", "origin", rama_actual])
            
            # Ejecuta el comando 'git push' para subir los cambios al repositorio remoto
            subprocess.run(["git", "push"])
            
            # Registra la acción en el historial
            self.registrar_accion(f"actualizó el repositorio remoto de la rama {rama_actual}")
            
            # Muestra un mensaje de éxito
            QMessageBox.information(self, "Actualización Remota", "Los cambios se han actualizado en el repositorio remoto.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al actualizar el repositorio remoto: {str(e)}")

    def git_add_commit_push(self, mensaje_commit):
        try:
            # Agregar los cambios
            subprocess.run(['git', 'add', '.'])
            
            # Hacer el commit
            subprocess.run(['git', 'commit', '-m', mensaje_commit])
            
            # Realizar el push
            subprocess.run(['git', 'push'])
            
            # Registra la acción en el historial
            self.registrar_accion(f'realizó un commit con el mensaje: "{mensaje_commit}"')
            
            # Muestra un mensaje de éxito
            QMessageBox.information(self, "Commit y Push", "Los cambios se han commiteado y enviado al repositorio remoto.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al hacer commit y push: {str(e)}")

    def initUI(self):
        self.setWindowTitle('Visualizador de Git')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()

        self.archivos_label = QLabel('Archivos en el Directorio:')
        layout.addWidget(self.archivos_label)

        self.archivos_output = QTextEdit()
        self.archivos_output.setReadOnly(True)
        layout.addWidget(self.archivos_output)

        self.mostrar_archivos_button = QPushButton('Mostrar Archivos')
        self.mostrar_archivos_button.clicked.connect(self.mostrar_archivos)
        layout.addWidget(self.mostrar_archivos_button)

        self.cambios_label = QLabel('Cambios en el Repositorio:')
        layout.addWidget(self.cambios_label)

        self.cambios_output = QTextEdit()
        self.cambios_output.setReadOnly(True)
        layout.addWidget(self.cambios_output)

        self.mostrar_cambios_button = QPushButton('Mostrar Cambios')
        self.mostrar_cambios_button.clicked.connect(self.mostrar_cambios)
        layout.addWidget(self.mostrar_cambios_button)

        # Boton actualizar repositorio
        self.actualizar_remoto_button = QPushButton('Actualizar Repositorio Remoto')
        self.actualizar_remoto_button.clicked.connect(self.actualizar_remoto)
        layout.addWidget(self.actualizar_remoto_button)

        # Nuevo campo de entrada para mostrar el nombre de usuario
        self.usuario_entry = QLineEdit()
        self.usuario_entry.setPlaceholderText('Usuario')
        self.usuario_entry.setReadOnly(True)
        self.usuario_entry.setText(self.username)  # Establecer el nombre de usuario aquí
        layout.addWidget(self.usuario_entry)

        # Agregar botones para realizar acciones en el directorio
        self.eliminar_archivo_button = QPushButton('Eliminar Archivo')
        self.eliminar_archivo_button.clicked.connect(self.eliminar_archivo)
        layout.addWidget(self.eliminar_archivo_button)

        self.modificar_archivo_button = QPushButton('Modificar Archivo')
        self.modificar_archivo_button.clicked.connect(self.modificar_archivo)
        layout.addWidget(self.modificar_archivo_button)

        # Agregar una lista desplegable para seleccionar la rama
        self.branch_label = QLabel('Seleccionar Rama:')
        layout.addWidget(self.branch_label)

        self.branch_combobox = QComboBox()
        self.detectar_ramas_disponibles()
        layout.addWidget(self.branch_combobox)

        # Agregar un botón para actualizar la vista según la rama seleccionada
        self.actualizar_button = QPushButton('Actualizar Vista')
        self.actualizar_button.clicked.connect(self.actualizar_vista)
        layout.addWidget(self.actualizar_button)

        self.mostrar_historial_button = QPushButton('Mostrar Historial')
        self.mostrar_historial_button.clicked.connect(self.mostrar_historial)
        layout.addWidget(self.mostrar_historial_button)

        # Botón para realizar commit y push
        self.commit_push_button = QPushButton('Commit y Push')
        self.commit_push_button.clicked.connect(self.hacer_commit_y_push)
        layout.addWidget(self.commit_push_button)

        central_widget.setLayout(layout)

    def mostrar_archivos(self):
        if sys.platform == 'win32':
            comando = ['dir']
        else:
            comando = ['ls']

        resultado = subprocess.run(comando, capture_output=True, text=True, shell=True)
        self.archivos_output.setPlainText(resultado.stdout)

    def mostrar_cambios(self):
        resultado = subprocess.run(['git', 'status'], capture_output=True, text=True, shell=True)
        self.cambios_output.setPlainText(resultado.stdout)

    def eliminar_archivo(self):
        archivo_a_eliminar = filedialog.askopenfilename()
        if archivo_a_eliminar:
            try:
                os.remove(archivo_a_eliminar)
                self.registrar_accion(f'eliminó el archivo {archivo_a_eliminar}')
                messagebox.showinfo('Eliminado', f'Se eliminó el archivo: {archivo_a_eliminar}')
            except Exception as e:
                messagebox.showerror('Error', f'Error al eliminar el archivo: {str(e)}')

    def modificar_archivo(self):
        # Abre un cuadro de diálogo para seleccionar el archivo a modificar
        archivo_a_modificar = QFileDialog.getOpenFileName(self, 'Seleccionar archivo a modificar')[0]
        if archivo_a_modificar:
            try:
                # Registra la acción de modificación en el historial
                self.registrar_accion(f'modificó el archivo "{archivo_a_modificar}"')
                
                # Abre el archivo en un editor de texto (puedes cambiar el comando según tu editor preferido)
                subprocess.run(["notepad.exe", archivo_a_modificar])
                messagebox.showinfo('Modificación', f'Se abrió el archivo para modificación: {archivo_a_modificar}')
            except Exception as e:
                messagebox.showerror('Error', f'Error al abrir el archivo para modificación: {str(e)}')

    def detectar_ramas_disponibles(self):
        repo = git.Repo('.')
        ramas = [str(branch) for branch in repo.branches]
        self.branch_combobox.addItems(ramas)

    def actualizar_vista(self):
        selected_branch = self.branch_combobox.currentText()
        repo = git.Repo('.')
        repo.git.checkout(selected_branch)
        messagebox.showinfo('Actualizado', f'Se cambió a la rama: {selected_branch}')
        self.mostrar_cambios()

    def mostrar_historial(self):
        try:
            with open('acciones.log', 'r') as archivo_log:
                historial = archivo_log.read()
                if historial.strip():  # Verifica si el historial no está vacío
                    historial_dialog = QDialog(self)
                    historial_dialog.setWindowTitle('Historial de Acciones')
                    historial_dialog.setGeometry(200, 200, 600, 400)

                    layout = QVBoxLayout()

                    historial_text = QPlainTextEdit()
                    historial_text.setReadOnly(True)
                    historial_text.setPlainText(historial)

                    layout.addWidget(historial_text)
                    historial_dialog.setLayout(layout)
                    historial_dialog.exec_()
                else:
                    print("El archivo de historial está vacío.")
        except FileNotFoundError:
            # Si el archivo no existe, muestra un mensaje
            print("El archivo de historial aún no ha sido creado.")

    def hacer_commit_y_push(self):
        mensaje_commit, ok = QInputDialog.getText(self, 'Mensaje de Commit', 'Por favor, ingresa el mensaje de commit:')
        if ok:
            self.git_add_commit_push(mensaje_commit)

class LoginWindow_supervisor(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.master.wm_geometry("400x225")
        self['bg'] = '#FFFFFF'
        self.container = tk.Frame(self)
        self.container['bg'] = "#FFFFFF"
        self.container.pack(fill='both', expand=1)
        self._create_widgets()
        self._place_widgets()

    def _create_widgets(self):
        self.user_label = tk.Label(self.container, text='User', font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.user_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
        )
        self.pass_label = tk.Label(self.container, text="Password", font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.pass_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
            show="*",
        )
        self.login_button = tk.Button(
            self.container,
            text='Login',
            font=('Segoe UI', 15),
            fg="#FFFFFF",
            bd=0,
            bg="#005486",
            highlightthickness=0,
            highlightbackground="#FFFFFF",
            activebackground="#009add",
            width=30,
            command=self.log_user_in
        )

    def _place_widgets(self):
        self.user_label.pack()
        self.user_entry.pack()
        self.pass_label.pack()
        self.pass_entry.pack()
        self.login_button.pack(pady=10)

    def log_user_in(self):
        global login_successful
        user = self.user_entry.get()
        password = self.pass_entry.get()
        domain = "americas.ad.flextronics.com"
        server = Server('10.10.28.70', use_ssl=True, get_info=ALL)
        full_user = user + '@' + domain
        try:
            conn = Connection(server, full_user, password, auto_bind=True)
        except Exception as e:
            messagebox.showerror(title='Error', message=str(e))
        else:
            conn.search(search_base='ou=users,ou=gdl,ou=mx,dc=americas,dc=ad,dc=flextronics,dc=com',
                         search_filter=f"""(&(objectClass=user)(sAMAccountname={user}))""",
                         search_scope=SUBTREE,
                         attributes=['displayname', 'title', 'sAMAccountname', 'employeeNumber', 'mail', 'personaltitle'])
            for entry in conn.response:
                attributes = entry['attributes']
            if attributes.get('title') in ['Debug Technician', 'Student'] or attributes.get('employeeNumber') == 'W':
                login_successful = True
                self.master.destroy()
                self.show_next_station(user)

    def show_next_station(self, username):
        if login_successful:
            app = QApplication(sys.argv)
            window = GitViewer(username=username)
            window.show()
            sys.exit(app.exec_())

def main():
    root = tk.Tk()
    root.title("Aplicación")
    login_window = LoginWindow_supervisor(root)
    login_window.pack(side='left', fill='both', expand=1)
    root.mainloop()

if __name__ == '__main__':
    main()



