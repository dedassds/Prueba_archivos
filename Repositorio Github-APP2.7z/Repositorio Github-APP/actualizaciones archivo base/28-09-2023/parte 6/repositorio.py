from datetime import date, timedelta

import os
import sys
import subprocess
import git
import difflib

from PyQt5.QtWidgets import ( QApplication, QMainWindow, QTextEdit, QVBoxLayout, QPushButton, QWidget, QLabel, QLineEdit, QPlainTextEdit, QDialog,
 QFileDialog, QMessageBox, QInputDialog, QGridLayout, QSplitter, QTreeView, QFileSystemModel, QHBoxLayout,
 QApplication, QMainWindow, QTableWidget, QTableWidgetItem)

from PyQt5.QtCore import Qt
import tkinter as tk
from tkinter import filedialog, messagebox
from ldap3 import Server, Connection, ALL, SUBTREE
from PyQt5.QtWidgets import QComboBox
from datetime import datetime
from PyQt5.QtGui import QFont, QIcon, QPixmap

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

#-----revisar librerias----------------

from PyQt5 import QtGui
from PyQt5 import QtWidgets

from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *


# Variable de bandera para el inicio de sesión exitoso
login_successful = False

#Variables de las rutas tanto master como el local
ruta1 = "C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Master\\Programa_2\\Repositorio Github-APP"
ruta2 ="C:\\Users\\gdlniper\\Desktop\\Nicolas Perea Santos\\AplicacionesNicolas\\Programa_2\\Repositorio Github-APP"

class VisualizadorTabla(QMainWindow):
    def __init__(self):
        super().__init__()

         # Datos de ejemplo para la tabla (puedes reemplazarlos con tus propios datos)
        data = [
            ["Nombre", "Edad", "País"],
            ["Alice", "25", "EE. UU."],
            ["Bob", "30", "Canadá"],
            ["Charlie", "28", "Reino Unido"],
        ]
        self.data = data
        self.iniciarUI()

    def iniciarUI(self):
        self.setWindowTitle('Visualizador de Datos')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Crear una tabla para mostrar los datos
        tabla = QTableWidget()
        tabla.setColumnCount(len(self.data[0]))
        tabla.setRowCount(len(self.data))

        # Agregar los datos a la tabla
        for fila, datos_fila in enumerate(self.data):
            for columna, valor in enumerate(datos_fila):
                item = QTableWidgetItem(str(valor))
                tabla.setItem(fila, columna, item)

        # Configurar encabezados de columnas
        encabezados = self.data[0]
        tabla.setHorizontalHeaderLabels(encabezados)

        # Ajustar el tamaño de las columnas para que se ajusten al contenido
        tabla.resizeColumnsToContents()

        layout = QVBoxLayout()
        layout.addWidget(tabla)
        central_widget.setLayout(layout)


def get_file_changes(commit_hash, file_path):
    repo = git.Repo('.')  
    commit = repo.commit(commit_hash)  
   
    previous_version = commit.parents[0] if commit.parents else None
    current_version = commit
    
    try:
        # Verificamos si el archivo existe en la versión anterior y en la versión actual
        if previous_version and file_path in [item.path for item in previous_version.tree.traverse()]:
            previous_content = previous_version.tree[file_path].data_stream.read().decode('utf-8')
        else:
            previous_content = ''
        
        if file_path in [item.path for item in current_version.tree.traverse()]:
            current_content = current_version.tree[file_path].data_stream.read().decode('utf-8')
        else:
            current_content = ''
        
        differ = difflib.Differ()
        diff = list(differ.compare(previous_content.splitlines(), current_content.splitlines()))
        
        changes = [line[2:] for line in diff if line.startswith('- ') or line.startswith('+ ')]
        
        return '\n'.join(changes)
    except KeyError:
        # Si hay un error al intentar acceder al archivo, simplemente retornamos una lista vacía
        return ''





def get_modified_files_from_commit(commit_count, specific_date, until_time):
    # Obtener la rama actual
    result = subprocess.run(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], capture_output=True, text=True)
    current_branch = result.stdout.strip()
    
    if specific_date == datetime.now().strftime('%d/%m/%Y'):
        specific_date = datetime.now().strftime('%d/%m/%Y')
        until_time = datetime.now().strftime('%H:%M:%S')
    
    result = subprocess.run(['git', 'log', '-n', commit_count, '--since', specific_date + " 00:00:00", '--until', specific_date + " " + until_time, '--name-status', current_branch], capture_output=True, text=True)
    
    output = result.stdout.split('\n')
    commits = []
    current_commit = None

    for line in output:
        if line.startswith("commit "):
            if current_commit:
                commits.append(current_commit)
            current_commit = {"hash": line.split(" ")[1], "files": []}
        elif line.startswith(("M\t", "A\t", "D\t")):
            status, file = line.split("\t", 1)
            file_info = {"status": status, "file": file, "changes": get_file_changes(current_commit["hash"], file)}
            current_commit["files"].append(file_info)
    
    if current_commit:
        commits.append(current_commit)
    
    return commits if commits else None



    


class GitViewer(QMainWindow):

    def __init__(self, username=None):
        super().__init__()
        self.username = username
        self.initUI()

        # Crear una instancia de VisualizadorTabla (aún no se muestra)
        self.ventana_tabla = VisualizadorTabla()
    
    def mostrar_tabla(self):
        # Mostrar la instancia de VisualizadorTabla cuando sea necesario
        self.ventana_tabla.show()
    
    def show_changes(self):
        # Clear the terminal
        self.text_master.clear()

        commit_count = self.commit_count_combo.currentText()
        specific_date = self.date_range_combo.currentText()
        
        # Adjust the time range for the current day
        from datetime import datetime
        current_date = datetime.now().strftime('%d/%m/%Y')
        until_time = "23:59:59"
        if specific_date == current_date:
            until_time = datetime.now().strftime('%H:%M:%S')
        
        commits = get_modified_files_from_commit(commit_count, specific_date, until_time)
        if not commits:
            self.text_master.appendPlainText("No hay commits de modificación de archivos")
            return

        # Crear un archivo de texto para guardar la información
        with open('cambios.txt', 'w') as archivo:
            for commit in commits:
                archivo.write(f"Commit Hash: {commit['hash']}\n")
                for file_info in commit['files']:
                    archivo.write(f"Archivo: {file_info['file']}\n")
                    archivo.write("\nCambios: ")
                    cambios_horizontales = ' '.join(file_info['changes'])
                    archivo.write(cambios_horizontales.replace(' ', '   ') + '\n')
                    # Mostrar la información en la terminal con espacio adicional
                    #self.text_master.appendPlainText(f"Commit Hash: {commit['hash']}")
                    self.text_master.appendPlainText(f"Archivo: {file_info['file']}")
                    self.text_master.appendPlainText("\nCambios:")
                    self.text_master.appendPlainText(f"{cambios_horizontales.replace(' ', '   ')}")
                    self.text_master.appendPlainText("\n")
                archivo.write("\n")

        self.text_master.appendPlainText("Los cambios se han guardado en el archivo 'cambios.txt'")





    
    def detectar_rama(self):
        try:
            resultado = subprocess.run(['git', 'branch', '--show-current'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al detectar la rama actual: {str(e)}")
            return "Rama Desconocida"
    
    def setup_watchdog(self):
        event_handler = FileModifiedHandler(self)
        observer = Observer()
        observer.schedule(event_handler, ruta1, recursive=True)
        observer.schedule(event_handler, ruta2, recursive=True)
        observer.start()
     
    
    def obtener_rama_actual(self):
        try:
            resultado = subprocess.run(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], capture_output=True, text=True, shell=True)
            return resultado.stdout.strip()
        except Exception as e:
            print(f"Error al obtener la rama actual: {str(e)}")
            return "Rama Desconocida"

    def registrar_accion(self, accion):
        username = self.username
        fecha = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        accion_registrada = f"{username} {accion} en la rama {self.detectar_rama()} a las {fecha}\n"
        
        # Comprueba si el archivo 'acciones.log' existe, y si no, lo crea
        if not os.path.exists('acciones.log'):
            with open('acciones.log', 'w') as archivo_log:
                archivo_log.write(accion_registrada)
        else:
            with open('acciones.log', 'a') as archivo_log:
                archivo_log.write(accion_registrada)
    
    def actualizar_remoto(self):
        try:
            # Detecta la rama actual
            rama_actual = self.obtener_rama_actual()
            
            # Configura la rama remota si no está configurada
            subprocess.run(["git", "push", "--set-upstream", "origin", rama_actual])
            
            # Ejecuta el comando 'git push' para subir los cambios al repositorio remoto
            subprocess.run(["git", "push"])
            
            # Registra la acción en el historial
            self.registrar_accion(f"actualizó el repositorio remoto de la rama {rama_actual}")
            
            # Muestra un mensaje de éxito
            QMessageBox.information(self, "Actualización Remota", "Los cambios se han actualizado en el repositorio remoto.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al actualizar el repositorio remoto: {str(e)}")

    

    def git_add_commit_push(self, mensaje_commit, ruta1, ruta2):
    #def git_add_commit_push(self, mensaje_commit):
        try:
            
            # Verificar si ambas rutas terminan en la misma carpeta
            if os.path.basename(os.path.normpath(ruta1)) == os.path.basename(os.path.normpath(ruta2)):
                # Ambas rutas terminan en la misma carpeta, proceder con commit y push en ambas rutas

                # Cambiar el directorio de trabajo a la primera ruta
                os.chdir(ruta1)

                # Agregar los cambios
                subprocess.run(['git', 'add', '.'])

                # Hacer el commit
                subprocess.run(['git', 'commit', '-m', mensaje_commit])

                # Realizar el pull
                subprocess.run(['git', 'pull'])

                # Realizar el push
                subprocess.run(['git', 'push'])

                # Cambiar el directorio de trabajo de vuelta a la segunda ruta
                os.chdir(ruta2)

                # Agregar los cambios
                subprocess.run(['git', 'add', '.'])

                # Hacer el commit
                subprocess.run(['git', 'commit', '-m', mensaje_commit])

                # Realizar el pull
                subprocess.run(['git', 'pull'])

                # Realizar el push
                subprocess.run(['git', 'push'])

                # Registra la acción en el historial
                # self.registrar_accion(f'realizó un commit con el mensaje: "{mensaje_commit}"')

                # Muestra un mensaje de éxito
                QMessageBox.information(self, "Commit y Push", "Los cambios se han commiteado y enviado al repositorio remoto en ambas rutas.")
            else:
                # Las rutas no terminan en la misma carpeta
                QMessageBox.warning(self, "Advertencia", "Las rutas no terminan en la misma carpeta. No se pueden realizar commit y push.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al hacer commit y push: {str(e)}")

        
    
    "resolver rutas"
    @classmethod #de esta manera lo defines como metodo de clase
    def resource_path(cls, relative_path):
        

        # Get absolute path to resource, works for dev and for PyInstaller 
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")

        return os.path.join(base_path, relative_path)

    def initUI(self):
        #-----propiedades ventana Controlador de versiones-------------

        self.setWindowTitle('Control de versiones')
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        #------Separacion de contenedores en la ventana--------------

        # Crear un splitter para dividir la ventana en tres secciones
        splitter = QSplitter()

        # Crear tres frames para cada sección
        top_frame = QWidget()
        left_frame = QWidget()
        right_frame = QWidget()

        # Configurar el splitter para dividir horizontalmente
        splitter.setOrientation(Qt.Horizontal)  # Utiliza 'Qt.Horizontal' en lugar de 1

        # Agregar los frames al splitter
        splitter.addWidget(top_frame)
        splitter.addWidget(left_frame)
        splitter.addWidget(right_frame)

        # Configurar el tamaño inicial de los frames
        splitter.setSizes([400, 100, 500])

        #-------Creacion de la disposición del Top frame----------------
       
        # Crear un layout vertical para el frame superior
        #top_layout = QHBoxLayout() #Oorganiza los widgets de manera horizontal
        top_layout = QVBoxLayout()
        
        # Establece los márgenes alrededor de top_layout
        top_layout.setContentsMargins(0, 0, 0, 0)  # Ajusta los valores según tus preferencias

        # Establece el espacio entre widgets dentro de top_layout
        top_layout.setSpacing(0)  # Ajusta el valor según tus preferencias
        

        # Establecer el splitter como widget central
        central_layout = QVBoxLayout()  # Crea un layout vertical para el widget central
        central_layout.addWidget(splitter)  # Agrega el splitter al layout central
        
        #Este elemento me indica como se va dividir la pantalla principal
        #central_widget.setLayout(central_layout)  # Establece el layout central en el widget central

         # Crear un layout de cuadrícula para organizar los tres frames
        grid_layout = QGridLayout()
        central_widget.setLayout(grid_layout)  # Establecer el layout de la ventana principal
  
        #grid_layout = QGridLayout()
        grid_layout.addWidget(top_frame, 0, 0, 1, 2)  # Frame superior ocupa dos columnas
        grid_layout.addWidget(left_frame, 1, 0)       # Frame izquierdo en la fila 1, columna 0
        grid_layout.addWidget(right_frame, 1, 1)      # Frame derecho en la fila 1, columna 1
        

        # Crear un layout para el frame derecho
        #Este layout le corresponde a colocar los elementos en cuadricula
        #layout = QGridLayout()
        layout = QVBoxLayout()

        # Crear un layout vertical para el frame izquierdo
        left_layout = QVBoxLayout()

        #--------------Right Frame ---------------------------------

        self.cambios_output = QTextEdit()
        self.cambios_output.setReadOnly(True)
        #layout.addWidget(self.cambios_output)

        self.mostrar_cambios_button = QPushButton('Mostrar Cambios')
        #self.mostrar_cambios_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.mostrar_cambios_button.clicked.connect(self.mostrar_cambios)
        self.mostrar_cambios_button.setMinimumWidth(50) 
        self.mostrar_cambios_button.setMaximumWidth(150)
        #layout.addWidget(self.mostrar_cambios_button)

        # Botón para revertir cambios
        self.revertir_cambios_button = QPushButton('Revertir Cambios')
        #self.revertir_cambios_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.revertir_cambios_button.clicked.connect(self.revertir_cambios)
        self.revertir_cambios_button.setMinimumWidth(50) 
        self.revertir_cambios_button.setMaximumWidth(150)
        #layout.addWidget(self.revertir_cambios_button)

        #------Botones para eliminar ----------    

        # Agregar un label a la ventana principal
        self.branch_commit = QLabel('Seleccionar Commit:')
        #self.branch_commit.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente

        # Agregar un combo box para seleccionar el commit a revertir
        self.commit_combobox = QComboBox()

        # Agregar un label a la ventana principal
        self.branch_label = QLabel('Seleccionar Rama:')
        #self.branch_label.setFont(QFont('Segoe UI', 14))  # Cambiar el estilo de fuente
        
        # Agregar un combo box para seleccionar las ramas
        self.branch_combobox = QComboBox()
        self.detectar_ramas_disponibles()

        # Agregar un botón para actualizar la vista según la rama seleccionada
        self.actualizar_button = QPushButton('Actualizar Vista')
        #self.actualizar_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.actualizar_button.clicked.connect(self.actualizar_vista)

        # Agregar un botón para actualizar la vista según los commits
        self.actualizar_button_commit = QPushButton('Actualizar Lista Commits')
        #self.actualizar_button_commit.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.actualizar_button_commit.clicked.connect(self.actualizar_vista_commit)

        self.mostrar_historial_button = QPushButton('Mostrar Historial')
        #self.mostrar_historial_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.mostrar_historial_button.clicked.connect(self.mostrar_historial)

        # Botón para realizar commit y push
        self.commit_push_button = QPushButton('Commit y Push')
        #self.commit_push_button.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.commit_push_button.clicked.connect(self.hacer_commit_y_push)

         # Crear un botón para el historial de cambios
        self.boton_prueba = QPushButton('Historial de cambios')
        #self.boton_prueba.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        self.boton_prueba.setMinimumWidth(50)  # Establece el ancho mínimo
        self.boton_prueba.setMaximumWidth(150)  # Establece el ancho máximo
        self.boton_prueba.clicked.connect(self.mostrar_tabla)

        #-------grupo para los botones mostrar y revertir cambios--------------

        verticalInnercambios = QVBoxLayout()
        verticalInnercambios.addWidget(self.mostrar_cambios_button)

        horizontalInnercambios = QHBoxLayout()
        horizontalInnercambios.addLayout( verticalInnercambios )
        horizontalInnercambios.addWidget( self.revertir_cambios_button )

        self.groupBox3 = QGroupBox( "Realizar cambios" )
        self.groupBox3.setLayout( horizontalInnercambios )



        #------Organizar elementos Right Frame --------------------------------

        verticalInnerLayout_repositorio = QVBoxLayout()
        verticalInnerLayout_repositorio.addWidget(self.cambios_output)
        #verticalInnerLayout_repositorio.addWidget(self.mostrar_cambios_button)
        #verticalInnerLayout_repositorio.addWidget(self.revertir_cambios_button)
        verticalInnerLayout_repositorio.addWidget(self.groupBox3)
        verticalInnerLayout_repositorio.addWidget(self.boton_prueba)
        verticalInnerLayout_repositorio.addWidget(self.branch_commit)       
        verticalInnerLayout_repositorio.addWidget(self.commit_combobox)
        verticalInnerLayout_repositorio.addWidget(self.branch_label)
        verticalInnerLayout_repositorio.addWidget(self.branch_combobox)
        verticalInnerLayout_repositorio.addWidget(self.actualizar_button)
        verticalInnerLayout_repositorio.addWidget(self.actualizar_button_commit)
        verticalInnerLayout_repositorio.addWidget(self.commit_push_button)

        self.groupBox_repositorio = QGroupBox( "Cambios en el Repositorio" )
        self.groupBox_repositorio.setLayout( verticalInnerLayout_repositorio )

        #-------------------------Frame Top ------------------------------

        #widgets para la imagen y el nombre del usuario
        self.usuario_label = QLabel('')
        self.usuario_label.setFont(QFont('Segoe UI', 14)) 
  
        self.usuario_label_login = QLabel('')
        self.usuario_label_login.setFont(QFont('Segoe UI', 14))
        self.usuario_label_login.setText(self.username)

        #Widget para colocar la imagen
        self.usuario_espacio = QLabel('')

        #Para el grupo de usuario

        verticalInnerLayout = QVBoxLayout()
        verticalInnerLayout.addWidget(self.usuario_label)
        verticalInnerLayout.addWidget(self.usuario_label_login)

        horizontalInnerLayout = QHBoxLayout()
        horizontalInnerLayout.addLayout( verticalInnerLayout )
        horizontalInnerLayout.addWidget( self.usuario_espacio )

        self.groupBox3 = QGroupBox( "Usuario" )
        self.groupBox3.setLayout( horizontalInnerLayout )

         #------Primer terminal--------------------------------------
        #widgets para la imagen y el nombre del usuario
        self.usuario_Archivo = QLabel('Master')
        #self.usuario_Archivo.setFont(QFont('Segoe UI', 14))
    
        self.text_master = QPlainTextEdit( self )
        self.show_changes_button = QPushButton("Show Changes", self)
        self.show_changes_button.clicked.connect(self.show_changes)
        self.show_changes_button.setGeometry(10, 420, 200, 40)

        #Modificacion del ancho
        self.text_master.setMinimumWidth(100)
        self.text_master.setMaximumWidth(400)

        #Modificacion de la altura
        self.text_master.setMinimumHeight(300)
        self.text_master.setMaximumHeight(600)

        #modificacion del ancho boton
        #self.startSimulationButton1.setMinimumWidth(50)
        #self.startSimulationButton1.setMaximumWidth(100)

        self.usuario_Archivo_2 = QLabel('Actual')

        self.text_Actual = QPlainTextEdit( self )

        #Modificacion del ancho
        self.text_Actual.setMinimumWidth(100)
        self.text_Actual.setMaximumWidth(400)

        #Modificacion de la altura
        self.text_Actual.setMinimumHeight(300)
        self.text_Actual.setMaximumHeight(600)

        verticalInnerLayout = QVBoxLayout()
        verticalInnerLayout.addWidget( self.usuario_Archivo)
        verticalInnerLayout.addWidget( self.text_master )

        verticalInnerLayout_2 = QVBoxLayout()
        verticalInnerLayout_2.addWidget( self.usuario_Archivo_2)
        verticalInnerLayout_2.addWidget( self.text_Actual )

        horizontalInnerLayout = QHBoxLayout()
        horizontalInnerLayout.addLayout( verticalInnerLayout )
        horizontalInnerLayout.addLayout( verticalInnerLayout_2 )
        

        self.groupBox1 = QGroupBox( "Comparación" )
        self.groupBox1.setLayout( horizontalInnerLayout )

         #------Segunda terminal----------------------
        #widgets para la imagen y el nombre del usuario
        #self.usuario_Archivo_2.setFont(QFont('Segoe UI', 14))
    

         # ComboBox for selecting number of commits
        self.commit_count_combo = QComboBox(self)
        self.commit_count_combo.addItems(["1","5", "10", "15", "20"])
        self.commit_count_combo.setGeometry(220, 420, 80, 30)

        # ComboBox for selecting specific dates from the last week
        self.date_range_combo = QComboBox(self)
        today = date.today()
        for i in range(7):
            day = today - timedelta(days=i)
            self.date_range_combo.addItem(day.strftime('%d/%m/%Y'))
        self.date_range_combo.setGeometry(310, 420, 100, 30)


        verticalInnerLayout = QVBoxLayout()
        verticalInnerLayout.addWidget( self.show_changes_button )

        horizontalInnerLayout = QHBoxLayout()
        horizontalInnerLayout.addLayout( verticalInnerLayout )
        horizontalInnerLayout.addWidget( self.commit_count_combo )
        horizontalInnerLayout.addWidget(  self.date_range_combo )

        self.groupBox2 = QGroupBox( "Filtros" )
        self.groupBox2.setLayout( horizontalInnerLayout )


        #modificar margenes
        self.usuario_label.setContentsMargins(0, 0, 0, 0)  # Establece los márgenes en cero
        self.usuario_label_login.setContentsMargins(0, 0, 0, 0)  # Establece los márgenes en cero

        #--------imagen usuario ------------

        # Carga la imagen utilizando resource_path
        imagen_path = self.resource_path('imagenes/user.png')
        pixmap = QPixmap(imagen_path)
        pixmap = pixmap.scaled(50, 50)
        self.usuario_label.setPixmap(pixmap)

         #-------imagen logo flex -----------

        # Carga la imagen utilizando resource_path
        imagen_path_2 = self.resource_path('imagenes/flex_loga.png')
        pixmap_2 = QPixmap(imagen_path_2)
        pixmap_2 = pixmap_2.scaled(100, 100)
        self.usuario_espacio.setPixmap(pixmap_2)

        #------------------------- Frame left  ------------------------------

        # Nuevo campo de entrada para mostrar el nombre de usuario
        self.Archivo_entry = QLineEdit()
        self.Archivo_entry.setPlaceholderText('Archivo')
        self.Archivo_entry.setReadOnly(True)
        self.Archivo_entry.setText("Aqui va el nombre del Archivo")  # Establecer el nombre de usuario aquí
        #self.Archivo_entry.setFont(QFont('Segoe UI', 12))  # Cambiar el estilo de fuente
        #layout.addWidget(self.usuario_entry)


    

        #horizontalInnerLayout = QHBoxLayout()
        #horizontalInnerLayout.addLayout( verticalInnerLayout_Archivo )
        #horizontalInnerLayout.addWidget( self.usuario_espacio )



        #-------------posicionamiento widgets right frame --------

        # Agregar widgets a la cuadrícula en celdas específicas
        #Ejemplo
        #layout.addWidget(self.archivos_label, 0, 0, 1, 2)  # (widget, row, column, rowspan, columnspan)


        #----Posicionamiento widgets right frame---------
        layout.addWidget(self.groupBox_repositorio)

        #------- posicionamiento widgets top frame ---------

        #top_layout.addWidget(self.usuario_label)
        #top_layout.addWidget( self.usuario_label_login)
        #top_layout.addWidget( self.usuario_espacio)
        top_layout.addWidget( self.groupBox3)
        top_layout.addWidget( self.groupBox1)
        top_layout.addWidget( self.groupBox2)
        

        #-------posicionamiento widgets left frame ---------

        #left_layout.addWidget(self.groupBox_Archivo)
        

        #------ carga de layouts a sus respectivos frames -----

        #central_widget.setLayout(layout)

        # Establecer el layout en el frame superior
        top_frame.setLayout(top_layout)  

        # Establecer el layout en el frame izquierdo
        left_frame.setLayout(left_layout)

        # Asignar el layout al frame derecho
        right_frame.setLayout(layout)
    
    
    def obtener_ultimos_archivos_agregados(self):
        try:
            # Ejecuta el comando 'git log' para obtener el historial de los últimos commits
            resultado = subprocess.run(['git', 'log', '--name-only', '--pretty=format:"%an, %ar : %s"'], 
                                        capture_output=True, text=True, shell=True)

            # Divide la salida en líneas
            lineas = resultado.stdout.splitlines()

            # Inicializa una lista para almacenar los archivos añadidos
            archivos_anadidos = []

            # Extrae los archivos añadidos de los últimos 10 commits
            for linea in lineas:
                # Comprueba si la línea comienza con '"' para indicar que es un archivo
                if linea.startswith('"'):
                    # Obtiene el nombre del archivo
                    nombre_archivo = linea.strip('"')

                    # Obtiene el autor del commit
                    autor = linea.split(' ')[0]

                    # Añade el archivo a la lista
                    archivos_anadidos.append({
                        'nombre_archivo': nombre_archivo,
                        'autor': autor,
                        'fecha': linea.split(' ')[1]
                    })

            # Verifica si el archivo log no existe
            if not os.path.exists('historial_archivos.log'):
                # Crea el archivo log
                with open('historial_archivos.log', 'w') as archivo_log:
                    archivo_log.write('')

            # Añade los archivos añadidos al archivo de registro (log)
            with open('historial_archivos.log', 'a') as archivo_log:
                for archivo_anadido in archivos_anadidos:
                    archivo_log.write(f"{archivo_anadido['nombre_archivo']} - {archivo_anadido['autor']}\n")

            # Convierte la lista de diccionarios a una lista de cadenas de texto
            archivos_anadidos_texto = [f"{archivo['nombre_archivo']} - {archivo['autor']}" for archivo in archivos_anadidos]

            # Muestra los últimos archivos añadidos en la terminal
            self.textEditWidget1.setPlainText('\n'.join(archivos_anadidos_texto))
            print(archivos_anadidos_texto)
        except Exception as e:
            self.textEditWidget1.setPlainText(f"Error al obtener el historial de archivos: {str(e)}")




 
    def revertir_cambios(self):
        selected_branch = self.branch_combobox.currentText()
        selected_commit = self.commit_combobox.currentText()

        if not selected_commit:
            QMessageBox.warning(self, "Advertencia", "Por favor, seleccione un commit para revertir.")
            return

        try:
            repo = git.Repo('.')
            # Cambiar a la rama seleccionada
            repo.git.checkout(selected_branch)

            # Obtener el hash del commit a partir del texto seleccionado
            with open('versiones.log', 'r') as version_log:
                commit_hash = None
                for line in version_log:
                    if selected_commit in line:
                        commit_hash = line.split('-')[1].strip()
                        break

            if commit_hash is None:
                QMessageBox.warning(self, "Advertencia", "No se pudo encontrar el hash del commit en versiones.log.")
                return

            # Utilizar git revert para deshacer completamente el commit seleccionado
            repo.git.revert("-n", commit_hash)  # -n para no hacer commit automático

            # Mostrar los cambios pendientes en un nuevo commit
            subprocess.run(["git", "status"], capture_output=True, text=True, shell=True)

            # Registrar la acción en el historial
            self.registrar_accion(f'revirtió completamente el commit {commit_hash} en la rama {selected_branch}')
            
            QMessageBox.information(self, "Revertir Cambios", f"El commit {commit_hash} se ha revertido completamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al revertir cambios: {str(e)}")


    def mostrar_archivos(self):
        if sys.platform == 'win32':
            comando = ['dir']
        else:
            comando = ['ls']

        resultado = subprocess.run(comando, capture_output=True, text=True, shell=True)
        self.archivos_output.setPlainText(resultado.stdout)

    def mostrar_cambios(self):
        resultado = subprocess.run(['git', 'status'], capture_output=True, text=True, shell=True)
        self.cambios_output.setPlainText(resultado.stdout)     

    def detectar_ramas_disponibles(self):
        repo = git.Repo('.')
        ramas = [str(branch) for branch in repo.branches]
        self.branch_combobox.addItems(ramas)

    def actualizar_vista(self):
        selected_branch = self.branch_combobox.currentText()
        repo = git.Repo('.')
        repo.git.checkout(selected_branch)
        messagebox.showinfo('Actualizado', f'Se cambió a la rama: {selected_branch}')
        self.mostrar_cambios()
    
    def actualizar_vista_commit(self):
        selected_branch = self.branch_combobox.currentText()
        repo = git.Repo('.')
        repo.git.checkout(selected_branch)
        self.mostrar_commits()  # Llama a mostrar_commits para llenar el combo box
        #self.git_add_commit_push("Commit forzado")

# ...

    def mostrar_commits(self):
        try:
            selected_branch = self.branch_combobox.currentText()
            repo = git.Repo('.')
            repo.git.checkout(selected_branch)
            commits = [(commit.hexsha, commit.message, commit.author.name, commit.committed_datetime) for commit in reversed(list(repo.iter_commits(selected_branch)))]

            # Invierte la lista de commits para mostrarlos en orden descendente
            commits.reverse()

            self.commit_combobox.clear()
            self.commit_combobox.addItem('Seleccionar Commit')  # Opción inicial

            # Calcula el número total de commits en la rama
            total_commits = len(commits)

            # Eliminar el archivo versiones.log si ya existe
            if os.path.exists('versiones.log'):
                os.remove('versiones.log')

            # Agregar encabezados al archivo versiones.log
            with open('versiones.log', 'a') as version_log:
                version_log.write("Versiones - Numero de Commit - Responsable - Fecha\n")

            # Recorre los commits y asigna versiones en orden descendente
            version = total_commits
            for commit_hash, commit_message, author_name, committed_datetime in commits:
                version_str = f'Version {version}.0.0'
                # Agregar el commit al archivo versiones.log
                with open('versiones.log', 'a') as version_log:
                    version_log.write(f'{version_str} - {commit_hash} - {self.username} - {committed_datetime}\n')
                self.commit_combobox.addItem(f'{version_str} - {commit_message}')
                version -= 1
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al obtener commits: {str(e)}")



    def mostrar_historial(self):
        try:
            with open('acciones.log', 'r') as archivo_log:
                historial = archivo_log.read()
                if historial.strip():  # Verifica si el historial no está vacío
                    historial_dialog = QDialog(self)
                    historial_dialog.setWindowTitle('Historial de Acciones')
                    historial_dialog.setGeometry(200, 200, 600, 400)

                    layout = QVBoxLayout()

                    historial_text = QPlainTextEdit()
                    historial_text.setReadOnly(True)
                    historial_text.setPlainText(historial)

                    layout.addWidget(historial_text)
                    historial_dialog.setLayout(layout)
                    historial_dialog.exec_()
                else:
                    print("El archivo de historial está vacío.")
        except FileNotFoundError:
            # Si el archivo no existe, muestra un mensaje
            print("El archivo de historial aún no ha sido creado.")

    def hacer_commit_y_push(self):
        mensaje_commit, ok = QInputDialog.getText(self, 'Mensaje de Commit', 'Por favor, ingresa el mensaje de commit:')
        if ok:
            self.git_add_commit_push(mensaje_commit,ruta1,ruta2)

# Nueva clase para manejar eventos de modificación de archivos con Watchdog
class FileModifiedHandler(FileSystemEventHandler):
    def __init__(self, git_viewer):
        self.git_viewer = git_viewer

    def on_modified(self, event):
        if event.is_directory:
            return
        if event.src_path.startswith(ruta1):
            self.sync_folders(ruta1, ruta2)
        elif event.src_path.startswith(ruta2):
            self.sync_folders(ruta2, ruta1)

    def sync_folders(self, src, dest):
        # Implementa la lógica de sincronización de carpetas aquí
        pass
class LoginWindow_supervisor(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.master.wm_geometry("400x225")
        self['bg'] = '#FFFFFF'
        self.container = tk.Frame(self)
        self.container['bg'] = "#FFFFFF"
        self.container.pack(fill='both', expand=1)
        self._create_widgets()
        self._place_widgets()

    def _create_widgets(self):
        self.user_label = tk.Label(self.container, text='User', font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.user_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
        )
        self.pass_label = tk.Label(self.container, text="Password", font=('Segoe UI', 15), fg="#000000", bg="#FFFFFF")
        self.pass_entry = tk.Entry(
            self.container,
            width=30,
            bg="#FFFFFF",
            fg="#000000",
            bd=0,
            highlightthickness=1,
            highlightbackground="#009ADD",
            font=('Segoe UI Semilight', 12),
            justify='center',
            show="*",
        )
        self.login_button = tk.Button(
            self.container,
            text='Login',
            font=('Segoe UI', 15),
            fg="#FFFFFF",
            bd=0,
            bg="#005486",
            highlightthickness=0,
            highlightbackground="#FFFFFF",
            activebackground="#009add",
            width=30,
            command=self.log_user_in
        )

    def _place_widgets(self):
        self.user_label.pack()
        self.user_entry.pack()
        self.pass_label.pack()
        self.pass_entry.pack()
        self.login_button.pack(pady=10)

    def log_user_in(self):
        global login_successful
        user = self.user_entry.get()
        password = self.pass_entry.get()
        domain = "nico.com"
        server = Server('5', use_ssl=True, get_info=ALL)
        full_user = user + '@' + domain
        try:
            conn = Connection(server, full_user, password, auto_bind=True)
        except Exception as e:
            messagebox.showerror(title='Error', message=str(e))
        else:
            conn.search(search_base='nico=com',
                         search_filter=f"""(&(objectClass=user)(sAMAccountname={user}))""",
                         search_scope=SUBTREE,
                         attributes=['displayname', 'title', 'sAMAccountname', 'employeeNumber', 'mail', 'personaltitle'])
            for entry in conn.response:
                attributes = entry['attributes']
            if attributes.get('title') in ['Debug Technician', 'Student'] or attributes.get('employeeNumber') == 'WD911888':
                login_successful = True
                self.master.destroy()
                self.show_next_station(user)

    def show_next_station(self, username):
        if login_successful:
            app = QApplication(sys.argv)
            window = GitViewer(username=username)
            window.setup_watchdog()  # Iniciar Watchdog
            window.show()
            sys.exit(app.exec_())

def main():
    #comentar para deshabilitar login
    #root = tk.Tk()
    #root.title("Aplicación")
    #login_window = LoginWindow_supervisor(root)
    #login_window.pack(side='left', fill='both', expand=1)
    #root.mainloop()

    #descomentar para iniciar directamente

    app = QApplication(sys.argv)

    # Crear una instancia de GitViewer y mostrarla

    window = GitViewer()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()




