from django import forms

from .models import Fixture


class FixtureForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(FixtureForm, self).__init__(*args, **kwargs)
        self.fields['equipment'].widget.attrs = {
            'class': 'form-select mb-3',
        }
        self.fields['model'].widget.attrs = {
            'class': 'form-select mb-3',
        }
        self.fields['fixture_file'].widget.attrs = {
            'class': 'form-control mb-3',
            'type': "file",
        }
        self.fields['wirelist_file'].widget.attrs = {
            'class': 'form-control mb-3',
            'type': "file",
        }


    class Meta:
        model = Fixture
        fields = '__all__'
        # fields = ['equipment', 'model']