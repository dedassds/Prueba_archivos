from django.db import transaction

from rest_framework import serializers

from .models import IYETTestedUnit, Measure, TestedUnit


class IYETTestedUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = IYETTestedUnit
        fields = '__all__'


class MeasureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Measure
        fields = '__all__'


class TestedUnitSerializer(serializers.ModelSerializer):
    tested_unit_iyet = IYETTestedUnitSerializer(many=True)
    tested_unit_measures = MeasureSerializer(many=True)

    class Meta:
        model = TestedUnit
        fields = '__all__'

    def create(self, validated_data):
        tested_unit_iyet = validated_data.pop('tested_unit_iyet')
        tested_unit_measures = validated_data.pop('tested_unit_measures')
        tested_unit_instance = TestedUnit.objects.create(**validated_data)
        with transaction.atomic(using='production'):
            IYETTestedUnit.objects.bulk_create(IYETTestedUnit(serial=tested_unit_instance, **iyet) for iyet in tested_unit_iyet)
            Measure.objects.bulk_create(Measure(serial=tested_unit_instance, **measure) for measure in tested_unit_measures)
        return tested_unit_instance