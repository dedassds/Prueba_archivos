from django.db import models


def content_fixture_file_name(instance, obj):
    new_filename = instance.model + "_fixture"
    new_filepath = "wpr_manager/" + instance.equipment + "/fixture"
    return '/'.join([new_filepath, new_filename])


def content_wirelist_file_name(instance, obj):
    new_filename = instance.model + "_wirelist"
    new_filepath = "wpr_manager/" + instance.equipment + "/wirelist"
    return '/'.join([new_filepath, new_filename])


class TestedUnit(models.Model):
    part_number = models.CharField(max_length=15)
    serial_number = models.CharField(max_length=11)
    start_time = models.DateTimeField()
    test_time = models.IntegerField()
    status_code = models.CharField(max_length=100)
    general_status = models.CharField(max_length=100)
    failing_test_name = models.CharField(max_length=100)
    file_name = models.CharField(max_length=100)
    model_name = models.CharField(max_length=100)
    family_name = models.CharField(max_length=100)
    customer_name = models.CharField(max_length=100, blank=True)
    ict_name = models.CharField(max_length=100)
    fixture_name = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.serial_number}'

    class Meta:
        verbose_name = 'Tested Unit List'
        verbose_name_plural = 'Tested Units List'
    


class IYETTestedUnit(models.Model):
    serial = models.ForeignKey('TestedUnit', on_delete=models.CASCADE, related_name="tested_unit_iyet", blank=True, null=True)
    failure_type = models.CharField(max_length=100, blank=True, null=True)
    start_node = models.CharField(max_length=100, blank=True, null=True)
    start_node_brc = models.CharField(max_length=100, blank=True, null=True)
    end_node = models.CharField(max_length=100, blank=True, null=True)
    end_node_brc = models.CharField(max_length=100, blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True, default=None)
    subtest = models.CharField(max_length=100, blank=True, null=True)
    measure = models.CharField(max_length=100, blank=True, null=True)
    threshold = models.CharField(max_length=100, blank=True, null=True)
    nominal = models.CharField(max_length=100, blank=True, null=True)
    high_limit = models.CharField(max_length=100, blank=True, null=True)
    low_limit = models.CharField(max_length=100, blank=True, null=True)
    vector = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)
    device = models.CharField(max_length=100, blank=True, null=True)
    pin = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f'{self.serial}'

    class Meta:
        verbose_name = 'IYET Records List'
        verbose_name_plural = 'IYET Records List'


class Measure(models.Model):
    serial = models.ForeignKey(TestedUnit, on_delete=models.CASCADE, related_name="tested_unit_measures", blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True, db_index=True)
    subtest = models.CharField(max_length=100, blank=True, null=True)
    status = models.BooleanField(max_length=100, blank=True, null=True, db_index=True)
    measure = models.FloatField(max_length=100, blank=True, null=True)
    nominal_value = models.FloatField(max_length=100, blank=True, null=True)
    high_limit = models.FloatField(max_length=100, blank=True, null=True)
    low_limit = models.FloatField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f'{self.serial} - {self.location} - {self.measure}'

    class Meta:
        verbose_name = 'Measure List'
        verbose_name_plural = 'Measures List'


class Fixture(models.Model):
    equipment = models.CharField(max_length=100, blank=True, null=True)
    model = models.CharField(max_length=100, blank=True, null=True)
    fixture_file = models.FileField(upload_to=content_fixture_file_name)
    wirelist_file = models.FileField(upload_to=content_wirelist_file_name)

    def __str__(self) -> str:
        return self.equipment

    class Meta:
        verbose_name = 'Fixture List'
        verbose_name_plural = 'Fixtures List'


class Pin(models.Model):
    fixture = models.ForeignKey(Fixture, on_delete=models.CASCADE, related_name='fixture')
    node = models.CharField(max_length=100)
    probe = models.CharField(max_length=100)
    tip_type = models.CharField(max_length=100, blank=True, null=True)
    center = models.CharField(max_length=100, blank=True, null=True)
    travel = models.CharField(max_length=100, blank=True, null=True)
    x_coordinate = models.PositiveIntegerField(blank=True, null=True)
    y_coordinate = models.PositiveIntegerField(blank=True, null=True)
    side = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self) -> str:
        return self.node

    class Meta:
        verbose_name = 'Pin List'
        verbose_name_plural = 'Pins List'


class UpgradedPin(models.Model):
    fixture = models.ForeignKey(Fixture, on_delete=models.CASCADE, related_name='upgraded_fixture')
    node = models.CharField(max_length=100)
    start_brc = models.PositiveIntegerField(blank=True, null=True)
    end_brc = models.PositiveIntegerField(blank=True, null=True)
    transfer = models.CharField(max_length=100, blank=True, null=True)
    transfer_x_coordinate = models.IntegerField(blank=True, null=True)
    transfer_y_coordinate = models.IntegerField(blank=True, null=True)
    probe = models.CharField(max_length=100, blank=True, null=True)
    probe_x_coordinate = models.IntegerField(blank=True, null=True)
    probe_y_coordinate = models.IntegerField(blank=True, null=True)
    terminal = models.CharField(max_length=100, blank=True, null=True)
    tip_type = models.CharField(max_length=100, blank=True, null=True)
    center = models.CharField(max_length=100, blank=True, null=True)
    travel = models.CharField(max_length=100, blank=True, null=True)
    side = models.CharField(max_length=100, default='BOTTOM')

    def __str__(self) -> str:
        return self.node

    class Meta:
        verbose_name = 'Upgraded Pin List'
        verbose_name_plural = 'Upgraded Pins List'


class Wire(models.Model):
    fixture = models.ForeignKey(Fixture, on_delete=models.CASCADE, related_name='component_fixture')
    test = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    node = models.CharField(max_length=100)
    brc = models.PositiveIntegerField()

    def __str__(self) -> str:
        return self.test

    class Meta:
        verbose_name = 'Wire List'
        verbose_name_plural = 'Wires List'


class TestedUnitSummary(TestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Test Results Dashboard'
        verbose_name_plural = 'Test Results Dashboard'


class TestCountSummary(TestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Test Count Dashboard'
        verbose_name_plural = 'Test Count Dashboard'


class EquipmentTestedUnitSummary(TestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Utilization Dashboard'
        verbose_name_plural = 'Utilization Dashboard'


class TestTimeTestedUnitSummary(TestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Test Time Dashboard'
        verbose_name_plural = 'Test Time Dashboard'


class IYETTestedUnitSummary(IYETTestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'IYET Dashboard'
        verbose_name_plural = 'IYET Dashboard'


class IYETTestedUnitSummary2(IYETTestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'IYET Dashboard - Single Records'
        verbose_name_plural = 'IYET Dashboard - Single Records'


class FixturePlotter(IYETTestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Fixture Plotter'
        verbose_name_plural = 'Fixture Plotter'


class UpgradedFixturePlotter(IYETTestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Upgraded Fixture Plotter'
        verbose_name_plural = 'Upgraded Fixture Plotter'


class NDFFixturePlotter(Wire):
    class Meta:
        proxy = True
        verbose_name = 'NDF Plotter'
        verbose_name_plural = 'NDF Plotter'


class MeasureSummary(Measure):
    class Meta:
        proxy = True
        verbose_name = 'CPK Dashboard'
        verbose_name_plural = 'CPK Dashboard'


class TaktTimeDashboard(TestedUnit):
    class Meta:
        proxy = True
        verbose_name = 'Takt Time Dashboard'
        verbose_name_plural = 'Takt Time Dashboard'