"""_summary_."""

import os
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass
class IyetData(object):
    """_summary_."""

    part_number: Any = ''
    serial_number: Any = ''
    start_time: Any = ''
    test_time: Any = ''
    status_code: Any = ''
    general_status: Any = ''
    failing_test_name: Any = ''
    file_name: Any = ''
    model_name: Any = ''
    ict_name: Any = ''
    fixture_name: Any = ''
    type: Any = ''
    start_node: Any = ''
    start_node_number: Any = ''
    end_node: Any = ''
    end_node_number: Any = ''
    location: Any = ''
    subtest: Any = ''
    measure: Any = ''
    threshold: Any = ''
    nominal: Any = ''
    high_limit: Any = ''
    low_limit: Any = ''
    vector: Any = ''
    status: Any = ''
    brrcc: Any = ''
    node: Any = ''
    pin: Any = ''


def measure_iyet(file_path):
    """Write iyet for measure and subtest match.

    Args:
        file_path (WindowsPath): Path to log file
    """
    regex_path = Path(r'C:\Users\gdlgjorg\Desktop\Test Station\Regexs_list.txt')
    with open(file_path, 'r') as log:
        log_contents = log.read()

    with open(regex_path, 'r') as rules:
        for rule in rules:
            cleaned = rule.strip()
            for error_match in re.finditer(cleaned, log_contents, re.MULTILINE):
                try:
                    assert error_match.groups()
                except AssertionError:
                    pass
                else:
                    keys = [group.lower() for group in error_match.re.groupindex]
                    match_result = dict(zip(keys, error_match.groups()))
                    iyet = IyetData(**match_result)
                    iyet.file_name = file_path
                    data_to_write = ','.join(list(asdict(iyet).values()))
                    with open('matches.txt', 'a') as db:
                        db.write(f'{data_to_write}\n')


folder = Path(r'C:\Logfiles\73-13196-XX\FAIL')
for root, _dirs, files in os.walk(folder):
    for file in files:
        measure_iyet(os.path.join(root, file))
