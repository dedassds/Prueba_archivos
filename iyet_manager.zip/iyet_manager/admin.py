﻿import calendar
import datetime
import json
from django.contrib import messages
import numpy as np
import pandas as pd
import pytz
from django.contrib import admin
from django.db.models import Count, Q, Sum
from django.db.models.functions import (ExtractDay, ExtractHour, ExtractWeek,
                                        Trunc, TruncHour)
from django.db.utils import OperationalError
from django.urls import reverse
from django.utils import timezone
from django.utils.html import format_html
from django.utils.http import urlencode
from django_admin_listfilter_dropdown.filters import (
    ChoiceDropdownFilter,
    DropdownFilter
    )
from quantiphy import Quantity
from import_export.admin import ExportActionMixin
from rangefilter.filters import DateTimeRangeFilter
from .models import (
    EquipmentTestedUnitSummary,
    Fixture,
    FixturePlotter,
    UpgradedFixturePlotter,
    IYETTestedUnit,
    IYETTestedUnitSummary,
    IYETTestedUnitSummary2,
    Measure,
    MeasureSummary,
    Pin,
    UpgradedPin,
    TestCountSummary,
    TestedUnit,
    TestedUnitSummary,
    TestTimeTestedUnitSummary,
    Wire,
    TaktTimeDashboard,
    NDFFixturePlotter
)

# Declaring general list
filter_list = [
    ('start_time', DateTimeRangeFilter),
    ('general_status', DropdownFilter),
    ('customer_name', DropdownFilter),
    ('family_name', DropdownFilter),
    ('part_number', DropdownFilter),
    ('model_name', DropdownFilter),
    ('failing_test_name', DropdownFilter),
    ('ict_name', DropdownFilter),
    ('fixture_name', DropdownFilter),
    ]


@admin.register(TestedUnit)
class TestedUnitAdmin(ExportActionMixin, admin.ModelAdmin):
    """_summary_.

    Args:
        admin (_type_): _description_
    """
    def iyet_findings_count(self, obj):
        count = obj.tested_unit_iyet.count()
        url = (
            reverse("admin:iyet_manager_iyettestedunit_changelist")
            + "?"
            + urlencode({"q": f"{obj.pk}"})
        )
        return format_html('<a href="{}">{} findings</a>', url, count)

    list_display = [
        'serial_number',
        'part_number',
        'model_name',
        'family_name',
        'general_status',
        'failing_test_name',
        'ict_name',
        'fixture_name',
        'start_time',
        'test_time',
        'iyet_findings_count',
        ]
    list_filter = filter_list
    search_fields = [
        'serial_number__exact',
        'part_number__contains',
        'model_name__contains',
        ]

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        query_condition = ' | '.join([f'Q(serial_number={serial})' for serial in search_term_list])
        appended_queryset = queryset.filter(serial_number__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct
    
    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        
        # Asserting queryset
        request_dict = dict(request.GET)
        print(request_dict)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response
        return response


@admin.register(IYETTestedUnit)
class IYETTestedUnitAdmin(ExportActionMixin, admin.ModelAdmin):
    """_summary_.

    Args:
        admin (_type_): _description_
    """
    @admin.display(ordering='serial__failing_test_name', description='Failing Test Name')
    def failing_test_name(self, obj):
        return obj.serial.failing_test_name

    @admin.display(ordering='serial__start_time', description='Start Time')
    def start_time(self, obj):
        return obj.serial.start_time

    list_display = [
        'serial',
        'failing_test_name',
        'failure_type',
        'start_time'
        ]

    list_filter = [
        ('serial__start_time', DateTimeRangeFilter),
        ('serial__general_status', DropdownFilter),
        ('serial__part_number', DropdownFilter),
        ('serial__model_name', DropdownFilter),
        ('failure_type', DropdownFilter),
        ('serial__ict_name', DropdownFilter),
        ('serial__fixture_name', DropdownFilter),
        ]

    search_fields = [
        'serial__pk',
        'serial__serial_number__contains',
        'serial__part_number__contains',
        'serial__model_name__contains',
        'location__contains'
        ]

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response
        data = qs.values('serial__part_number', 'serial__serial_number').annotate(pass_total=Count('serial__serial_number',filter=Q(general_status='Pass')),fail_total=Count('serial_number',filter=Q(general_status='Fail')),total=Count('serial__serial_number')).order_by('-total')
        response.context_data['activation_count'] = data
        return response

    def get_list_display(self, request):
        # Defining simple list and extra fields based on
        # specific failing_test_name
        ORIGINAL_LIST_DISPLAY = [
            'serial',
            'failing_test_name',
            'failure_type',
            'start_time'
            ]
        SPECIAL_LIST_DISPLAY = {
            'Analog': ['location', 'subtest', 'measure', 'nominal', 'high_limit', 'low_limit'],
            'Analog_Functional': ['location', 'subtest', 'measure', 'nominal', 'high_limit', 'low_limit'],
            'Analog_Cluster': ['location', 'measure', 'nominal', 'high_limit', 'low_limit'],
            'Digital': ['location', 'vector', 'start_node', 'pin'],
            'Functional': ['location', 'vector', 'status', 'start_node', 'start_node_brc', 'pin'],
            'Pin_Test': ['start_node', ''],
            'Power_Supplies': ['location', ''],
            'Pre-shorts': ['location', 'measure', 'threshold',],
            'Pre-Prowered': ['location', ''],
            'Shorts': ['measure','threshold','start_node', 'start_node_brc', 'end_node', 'end_node_brc'],
            'Open': ['measure','threshold','start_node', 'start_node_brc', 'end_node', 'end_node_brc'],
            'TestJet': ['location', 'measure', 'start_node', 'pin', 'start_node_brc'],
        }
        request_dict = dict(request.GET)
        try:
            assert request_dict['failure_type']
        except (AssertionError, KeyError):
            list_display = ORIGINAL_LIST_DISPLAY
            return list_display
        failing_test_name = request_dict['failure_type'][0]
        list_display = ORIGINAL_LIST_DISPLAY
        extra_fields = SPECIAL_LIST_DISPLAY[failing_test_name]
        list_display.extend(extra_fields)
        return list_display

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        appended_queryset = queryset.filter(serial__serial_number__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct


@admin.register(IYETTestedUnitSummary2)
class IYETTestedUnitsSummaryAdmin2(ExportActionMixin, admin.ModelAdmin):
    change_list_template = 'admin/iyet_tested_units_summary_change_list2.html'
    list_filter = [('serial__start_time', DateTimeRangeFilter),
                   ('serial__general_status', DropdownFilter),
                   ('serial__family_name', DropdownFilter),
                   ('serial__model_name', DropdownFilter),
                   ('serial__ict_name', DropdownFilter),
                   ('serial__fixture_name', DropdownFilter)
                   ]

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['serial__start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response
        
        # Generating dataset for general status
        dataset = qs.values('serial__serial_number', 'serial__general_status').annotate(hour=ExtractHour('serial__start_time'))

        # Load list to queryset
        df = pd.DataFrame(dataset)
        df = df.drop_duplicates(subset=['serial__serial_number','hour','serial__general_status'])
        df = df.groupby(['serial__general_status','hour'], as_index=False).agg(total=pd.NamedAgg(column='serial__general_status', aggfunc='count'))

        # Sorting data by failing test hour (hourly)
        df1= pd.pivot_table(df, index="serial__general_status", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1 = df1.reset_index()

        # Passing data to template context
        response.context_data['df1'] = df1

        # Generating dataset for failing test name
        dataset2 = list(qs.values('failure_type').annotate(total=Count('failure_type')).values('failure_type','total').annotate(hour=ExtractHour('serial__start_time')).order_by('failure_type'))

        # Load list to queryset
        df = pd.DataFrame(dataset2)

        # Sorting data by failing test hour (hourly)
        df1 =pd.pivot_table(df, index="failure_type", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1 = df1.assign(sortkey=df1.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df2 = df1
        df1 = df1.reset_index()

        response.context_data['df2'] = df1

        """
            This section query DB to get data from failed locations. Each IYET records belong to one unit and count as a repeated value
            when two or more location or start node are the same. Failing test name doesn't matter, only locations will be processed
            and showed in dashboard.
        """

        # Generating dataset for location
        dataset3 = qs.values('serial__serial_number','serial__start_time','location').annotate(hour=ExtractHour('serial__start_time'))

        # Load list to queryset
        df_by_location = pd.DataFrame(dataset3)
        df_by_location = df_by_location.drop_duplicates(subset=['serial__serial_number','serial__start_time','location'])
        df_by_location = df_by_location.groupby(['hour','location'], as_index=False).agg(total=pd.NamedAgg(column='location', aggfunc='count'))
        df_by_location = df_by_location.sort_values(by=['total'], ascending=False)
        df_by_location['location'].replace('', np.nan, inplace=True)
        df_by_location.dropna(subset=['location'],inplace=True)

        # Sorting data by location (hourly)
        df1_location =pd.pivot_table(df_by_location, index="location", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1_location = df1_location.assign(sortkey=df1_location.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df1_location = df1_location.head(10)
        df1_location = df1_location.reset_index()

        # Passing data to context
        response.context_data['df3'] = df1_location

        # Creating general graph
        categories =  df1.failure_type.to_list()
        totals =  df1.Total.to_list()
        # Cleaning lists
        categories.pop(-1)
        totals.pop(-1)
        # Creating JSON for JavaScript code
        response.context_data['chart_data'] = json.dumps({
            'chart': {
                'renderTo': 'chart-container',
                'reflow': 'true',
                'type': 'column',
            },
            'title': {
                'text': 'Units with failure'
            },
            'tooltip': {
                'shared': 'true'
            },
            'xAxis': {
                'categories': categories,
                'crosshair': 'true'
            },
            'yAxis': [{
                'title': {
                    'text': ''
                }
            }, {
                'title': {
                    'text': ''
                },
                'minPadding': 0,
                'maxPadding': 0,
                'max': 100,
                'min': 0,
                'opposite': 'true',
                'labels': {
                    'format': "{value}%"
                }
            }],
            'series': [{
                'type': 'pareto',
                'name': 'Pareto',
                'yAxis': 1,
                'zIndex': 10,
                'baseSeries': 1,
                'tooltip': {
                    'valueDecimals': 2,
                    'valueSuffix': '%'
                }
            }, {
                'name': 'Failures',
                'type': 'column',
                'zIndex': 2,
                'data': totals
            }]
        })

        # Creating specific graph
        auxiliar_data = dict(zip(categories, totals))
        df2 = df2.drop(columns=['Total'])
        response.context_data['admin_chart2'] = json.dumps({
            'chart': {
            'type': 'column',
            'events': {
                'render': 'function() { this.reflow();}'
            }
            },
            'title': {
                'align': 'left',
                'text': 'Failure Units by Failing Test Name'
            },
            'subtitle': {
                'align': 'left',
                'text': 'Click the columns to view hour by hour detail.'
            },
            'accessibility': {
                'announceNewData': {
                    'enabled': 'true'
                }
            },
            'xAxis': {
                'type': 'category'
            },
            'yAxis': {
                'title': {
                    'text': 'Total percent market share'
                }

            },
            'legend': {
                'enabled': 'false'
            },
            'plotOptions': {
                'series': {
                    'borderWidth': 0,
                    'dataLabels': {
                        'enabled': 'true',
                        'format': '{point.y:.1f}'
                    }
                }
            },

            'tooltip': {
                'headerFormat': '<span style="font-size:11px">{series.name}</span><br>',
                'pointFormat': '<span style="color:{point.color}"> {point.name}</span><b>{point.y:.0f}</b> failures<br/>'
            },

            'series': [
                {
                    'name': "Failing Test Names",
                    'colorByPoint': 'true',
                    'data': list(map(lambda row: {'name': row, 'y': auxiliar_data[row], 'drilldown': row}, auxiliar_data))
                }
            ],
            'drilldown': {
                'breadcrumbs': {
                    'position': {
                        'align': 'right'
                    }
                },
                'series': list(map(lambda row: dict(name=row, id=row, data=list(zip([str(value) for value in df2.columns.to_list()], [int(value) for value in df2.loc[row].to_list()]))), categories))
            }})

        return response


@admin.register(TestCountSummary)
class TestCountSummaryAdmin(ExportActionMixin, admin.ModelAdmin):
    change_list_template = 'admin/activation_count_change_list.html'
    list_filter = filter_list
    search_fields = ['serial_number__contains', 'part_number__contains', 'model_name__contains']
    sortable_by = ['part_number', 'serial_number']
    view_on_site = True

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response
        data = qs.values('part_number', 'serial_number').annotate(pass_total=Count('serial_number',filter=Q(general_status='Pass')),fail_total=Count('serial_number',filter=Q(general_status='Fail')),total=Count('serial_number')).order_by('-total')
        response.context_data['activation_count'] = data
        return response

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        query_condition = ' | '.join([f'Q(serial_number={serial})' for serial in search_term_list])
        appended_queryset = queryset.filter(serial_number__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct


@admin.register(TestTimeTestedUnitSummary)
class TestTimeTestedUnitAdmin(ExportActionMixin, admin.ModelAdmin):
    change_list_template = 'admin/test_time_change_list.html'
    list_filter = filter_list
    list_display = ['part_number','serial_number','test_time','ict_name','fixture_name']

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response

        request_dict = dict(request.GET)
        if len(request_dict.get('model_name', 'Error')) == 1:
            response.context_data['special_title'] = request_dict['model_name'][-1]
        # Generating dataset for test time by model
        dataset = list(qs.values('model_name', 'part_number', 'ict_name', 'fixture_name', 'test_time'))
        if not dataset:
            return response
        df = pd.DataFrame(dataset).set_index(['model_name', 'part_number', 'ict_name', 'fixture_name'])
        if df.empty:
            return response
        # Fixing value type in column
        df['test_time'] = df['test_time'].astype(int)
        # Calculating std deviation
        df1 = df.groupby(level=['model_name', 'part_number', 'ict_name', 'fixture_name']).agg(np.std, ddof=1)
        df1 = df1.reset_index()
        df1 = df1.rename(columns={'test_time':'std_deviation'})
        # Calculating mean
        df2 = df.groupby(level=['model_name', 'part_number', 'ict_name', 'fixture_name']).mean()
        df2 = df2.reset_index()
        # Counting model name ocurrence
        df3 = df.groupby(level=['model_name', 'part_number', 'ict_name', 'fixture_name']).count()
        df3 = df3.reset_index()
        # Counting model name ocurrence
        df4 = df.groupby(level=['model_name', 'part_number', 'ict_name', 'fixture_name'])['test_time'].max()
        df4 = df4.reset_index()
        # Counting model name ocurrence
        df5 = df.groupby(level=['model_name', 'part_number', 'ict_name', 'fixture_name'])['test_time'].min()
        df5 = df5.reset_index()
        print(df5)
        # Appending data to main DataFrame
        df1['average_test_time'] = df2['test_time']
        df1['tested_units'] = df3['test_time']
        df1['max'] = df4['test_time']
        df1['min'] = df5['test_time']
        # Fixing nan in columns
        df1['std_deviation'] = df1['std_deviation'].fillna(0)
        # Sorting columns
        df1 = df1.sort_values(by=['model_name', 'part_number', 'tested_units'], ascending=[True, True, False])
        # Truncking decimals to 3 positions only
        df1['average_test_time'] = np.trunc(1000*df1['average_test_time'])/1000
        df1['std_deviation'] = np.trunc(1000*df1['std_deviation'])/100
        print(df1)
        # Passing data to context
        response.context_data['average_test_time'] = df1

        # Creating normal distribution graphic
        data = df1.average_test_time.to_list()

        response.context_data['chart_data'] = json.dumps(
            {
                'title': {
                    'text': 'Bell curve'
                    },
                    'xAxis': [
                        {
                            'title': {
                                'text': 'Data'
                                },
                            'alignTicks': 'false'
                            },
                            {
                                    'title': {
                                        'text': 'Bell curve'
                                        },
                                        'alignTicks': 'false',
                                        'opposite': 'true'
                                        }
                                        ],
                                        'yAxis': [
                                            {
                                                'title': {
                                                    'text': 'Data'
                                                    }
                                                    },
                                                    {
            'title': { 'text': 'Bell curve' },
            'opposite': 'true'
        }],

        'series': [{
            'name': 'Bell curve',
            'type': 'histogram',
            'xAxis': 1,
            'yAxis': 1,
            'baseSeries': 1,
            'zIndex': -1
        }, {
            'name': 'Data',
            'type': 'scatter',
            'data': data,
            'accessibility': {
                'exposeAsGroupOnly': 'true'
            },
            'marker': {
                'radius': 1.5
            }
        }]})

        return response

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        query_condition = ' | '.join([f'Q(serial_number={serial})' for serial in search_term_list])
        appended_queryset = queryset.filter(serial_number__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct


""" Summaries start here. """


@admin.register(TestedUnitSummary)
class TestedUnitsSummaryAdmin(ExportActionMixin, admin.ModelAdmin):
    change_list_template = 'admin/tested_units_summary_change_list.html'
    list_filter = filter_list

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        # Asserting queryset
        request_dict = dict(request.GET)
        print(request_dict)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response


        # Generating dataset for general status
        dataset = list(qs.values('general_status').annotate(total=Count('general_status')).values('general_status','total').annotate(hour=ExtractHour('start_time')).order_by('general_status'))

        if not dataset:
            return response
        # Load list to queryset
        df = pd.DataFrame(dataset)

        # Sorting data by failing test hour (hourly)
        df1= pd.pivot_table(df, index="general_status", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        yields = []
        try:
            for value in zip(df1.loc['Pass'].to_list(), df1.loc['Total'].to_list()):
                yields.append("{0:.0%}".format(value[0]/value[1]))
            df1.loc['Yield'] = yields
        except KeyError:
            pass
        df1 = df1.reset_index()

        # Passing data to template context
        response.context_data['df1'] = df1


        # Generating dataset for failing test name
        dataset2 = list(qs.values('failing_test_name').annotate(total=Count('failing_test_name')).exclude(failing_test_name='Pass').values('failing_test_name','total').annotate(hour=ExtractHour('start_time')).order_by('failing_test_name'))

        # Load queryset to DataFrame
        df = pd.DataFrame(dataset2)

        # Sorting data by failing test hour (hourly)
        df1 =pd.pivot_table(df, index="failing_test_name", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1 = df1.assign(sortkey=df1.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df2 = df1
        df1 = df1.reset_index()

        response.context_data['df2'] = df1

        # Creating general graph
        categories =  df1.failing_test_name.to_list()
        totals =  df1.Total.to_list()
        # Cleaning lists
        categories.pop(-1)
        totals.pop(-1)
        # Creating JSON for JavaScript code
        response.context_data['chart_data'] = json.dumps({
            'chart': {
                'renderTo': 'chart-container',
                'reflow': 'true',
                'type': 'column',
            },
            'title': {
                'text': 'Units with failure'
            },
            'tooltip': {
                'shared': 'true'
            },
            'xAxis': {
                'categories': categories,
                'crosshair': 'true'
            },
            'yAxis': [{
                'title': {
                    'text': ''
                }
            }, {
                'title': {
                    'text': ''
                },
                'minPadding': 0,
                'maxPadding': 0,
                'max': 100,
                'min': 0,
                'opposite': 'true',
                'labels': {
                    'format': "{value}%"
                }
            }],
            'series': [{
                'type': 'pareto',
                'name': 'Pareto',
                'yAxis': 1,
                'zIndex': 10,
                'baseSeries': 1,
                'tooltip': {
                    'valueDecimals': 2,
                    'valueSuffix': '%'
                }
            }, {
                'name': 'Failures',
                'type': 'column',
                'zIndex': 2,
                'data': totals
            }]
        })

        # Creating specific graph
        auxiliar_data = dict(zip(categories, totals))
        df2 = df2.drop(columns=['Total'])
        response.context_data['admin_chart2'] = json.dumps({
            'chart': {
            'type': 'column',
            'events': {
                'render': 'function() { this.reflow();}'
            }
            },
            'title': {
                'align': 'left',
                'text': 'Failure Units by Failing Test Name'
            },
            'subtitle': {
                'align': 'left',
                'text': 'Click the columns to view hour by hour detail.'
            },
            'accessibility': {
                'announceNewData': {
                    'enabled': 'true'
                }
            },
            'xAxis': {
                'type': 'category'
            },
            'yAxis': {
                'title': {
                    'text': 'Total percent market share'
                }

            },
            'legend': {
                'enabled': 'false'
            },
            'plotOptions': {
                'series': {
                    'borderWidth': 0,
                    'dataLabels': {
                        'enabled': 'true',
                        'format': '{point.y:.1f}'
                    }
                }
            },

            'tooltip': {
                'headerFormat': '<span style="font-size:11px">{series.name}</span><br>',
                'pointFormat': '<span style="color:{point.color}"> {point.name}</span><b>{point.y:.0f}</b> failures<br/>'
            },

            'series': [
                {
                    'name': "Failing Test Names",
                    'colorByPoint': 'true',
                    'data': list(map(lambda row: {'name': row, 'y': auxiliar_data[row], 'drilldown': row}, auxiliar_data))
                }
            ],
            'drilldown': {
                'breadcrumbs': {
                    'position': {
                        'align': 'right'
                    }
                },
                'series': list(map(lambda row: dict(name=row, id=row, data=list(zip([str(value) for value in df2.columns.to_list()], [int(value) for value in df2.loc[row].to_list()]))), categories))
            }})
        return response


@admin.register(IYETTestedUnitSummary)
class IYETTestedUnitsSummaryAdmin(ExportActionMixin, admin.ModelAdmin):
    """_summary_

    Args:
        ExportActionMixin (_type_): _description_
        admin (_type_): _description_

    Returns:
        _type_: _description_
    """

    change_list_template = 'admin/iyet_tested_units_summary_change_list.html'
    list_filter = [
        ('serial__start_time', DateTimeRangeFilter),
        ('serial__general_status', DropdownFilter),
        ('serial__part_number', DropdownFilter),
        ('serial__model_name', DropdownFilter),
        ('serial__failing_test_name', DropdownFilter),
        ('serial__ict_name', DropdownFilter),
        ('serial__fixture_name', DropdownFilter),
        ]
    search_fields = ['serial__serial_number__iexact', 'serial__part_number__contains', 'serial__model_name__contains', 'location__contains']

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['serial__start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response


        # Generating dataset for general status
        dataset = list(qs.values('serial__general_status').annotate(total=Count('serial__general_status')).values('serial__general_status','total').annotate(hour=ExtractHour('serial__start_time')).order_by('serial__general_status'))

        # Load list to queryset
        df = pd.DataFrame(dataset)

        # Sorting data by failing test hour (hourly)
        if df.empty:
            return response
        df1= pd.pivot_table(df, index="serial__general_status", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1 = df1.reset_index()

        # Passing data to template context
        response.context_data['df1'] = df1


        # Generating dataset for failing test name
        dataset2 = list(qs.values('failure_type').annotate(total=Count('failure_type')).values('failure_type','total').annotate(hour=ExtractHour('serial__start_time')).order_by('failure_type'))

        # Load list to queryset
        df = pd.DataFrame(dataset2)

        # Sorting data by failing test hour (hourly)
        df1 =pd.pivot_table(df, index="failure_type", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1 = df1.assign(sortkey=df1.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df2 = df1
        df1 = df1.reset_index()

        response.context_data['df2'] = df1


        # Generating dataset for location
        dataset3 = list(qs.values('location').annotate(total=Count('location')).values('location','total').annotate(hour=ExtractHour('serial__start_time')).order_by('location'))

        # Load list to queryset
        df_location = pd.DataFrame(dataset3)

        # Sorting data by location (hourly)
        df1_location =pd.pivot_table(df_location, index="location", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1_location = df1_location.assign(sortkey=df1_location.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df1_location = df1_location.head(50)
        df1_location = df1_location.reset_index()

        response.context_data['df3'] = df1_location

        # Generating dataset for node
        dataset4 = list(qs.values('start_node').annotate(total=Count('start_node')).values('start_node','total').annotate(hour=ExtractHour('serial__start_time')).order_by('start_node'))

        # Load list to queryset
        df_node = pd.DataFrame(dataset4)

        # Sorting data by node(hourly)
        df1_node = pd.pivot_table(df_node, index="start_node", columns='hour', values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df1_node = df1_node.assign(sortkey=df1_node.index == 'Total')\
                .sort_values(['sortkey','Total'], ascending=[True, False])\
                .drop('sortkey', axis=1)
        df1_node = df1_node.head(20)
        df1_node = df1_node.reset_index()

        response.context_data['df4'] = df1_node

        # Creating general graph
        categories =  df1.failure_type.to_list()
        totals =  df1.Total.to_list()
        # Cleaning lists
        categories.pop(-1)
        totals.pop(-1)
        # Creating JSON for JavaScript code
        response.context_data['chart_data'] = json.dumps({
            'chart': {
                'renderTo': 'chart-container',
                'reflow': 'true',
                'type': 'column',
            },
            'title': {
                'text': 'Units with failure'
            },
            'tooltip': {
                'shared': 'true'
            },
            'xAxis': {
                'categories': categories,
                'crosshair': 'true'
            },
            'yAxis': [{
                'title': {
                    'text': ''
                }
            }, {
                'title': {
                    'text': ''
                },
                'minPadding': 0,
                'maxPadding': 0,
                'max': 100,
                'min': 0,
                'opposite': 'true',
                'labels': {
                    'format': "{value}%"
                }
            }],
            'series': [{
                'type': 'pareto',
                'name': 'Pareto',
                'yAxis': 1,
                'zIndex': 10,
                'baseSeries': 1,
                'tooltip': {
                    'valueDecimals': 2,
                    'valueSuffix': '%'
                }
            }, {
                'name': 'Failures',
                'type': 'column',
                'zIndex': 2,
                'data': totals
            }]
        })

        # Creating specific graph
        auxiliar_data = dict(zip(categories, totals))
        df2 = df2.drop(columns=['Total'])
        response.context_data['admin_chart2'] = json.dumps({
            'chart': {
            'type': 'column',
            'events': {
                'render': 'function() { this.reflow();}'
            }
            },
            'title': {
                'align': 'left',
                'text': 'Failure Units by Failing Test Name'
            },
            'subtitle': {
                'align': 'left',
                'text': 'Click the columns to view hour by hour detail.'
            },
            'accessibility': {
                'announceNewData': {
                    'enabled': 'true'
                }
            },
            'xAxis': {
                'type': 'category'
            },
            'yAxis': {
                'title': {
                    'text': 'Total percent market share'
                }

            },
            'legend': {
                'enabled': 'false'
            },
            'plotOptions': {
                'series': {
                    'borderWidth': 0,
                    'dataLabels': {
                        'enabled': 'true',
                        'format': '{point.y:.1f}'
                    }
                }
            },

            'tooltip': {
                'headerFormat': '<span style="font-size:11px">{series.name}</span><br>',
                'pointFormat': '<span style="color:{point.color}"> {point.name}</span><b>{point.y:.0f}</b> failures<br/>'
            },

            'series': [
                {
                    'name': "Failing Test Names",
                    'colorByPoint': 'true',
                    'data': list(map(lambda row: {'name': row, 'y': auxiliar_data[row], 'drilldown': row}, auxiliar_data))
                }
            ],
            'drilldown': {
                'breadcrumbs': {
                    'position': {
                        'align': 'right'
                    }
                },
                'series': list(map(lambda row: dict(name=row, id=row, data=list(zip([str(value) for value in df2.columns.to_list()], [int(value) for value in df2.loc[row].to_list()]))), categories))
            }})

        # Generating dataset for location
        """measures = list(qs.values('start_time','location','measure','high_limit','low_limit'))
        df_measures = pd.DataFrame(measures)
        averages = [list(value) for value in df_measures['measure'].to_list()]
        high_range = df_measures['high_limit'].to_list()
        low_range = df_measures['low_limit'].to_list()
        ranges = list(map(list,zip(low_range, high_range)))"""

        ranges = [
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            [11.7, 25.6],
            ]

        averages = [
            [18.1],
            [17.1],
            [15.2],
            [12.7],
            [13.3],
            [10.6],
            [15.6],
            [16.1],
            [14.0],
            [15.3],
            [17.5],
            [17.5],
            [15.3],
            [13.9],
            [11.7],
            [13.8],
            [14.0],
            [15.8],
            [18.6],
            [21.5],
            [19.8],
            [17.6],
            [16.8],
            [15.6],
            [16.7],
            [16.3],
            [17.2],
            [16.0],
            [16.9],
            [16.1],
            [14.5]
        ]

        nominal = [
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
            [18.1],
        ]

        response.context_data['component_graph'] = json.dumps(
                {
                    'title': {
                        'text': 'Dispersion data by location'
                    },

                    'subtitle': {
                        'text': 'this'
                    },

                    'xAxis': {
                        'type': 'int',
                        'accessibility': {
                            'rangeDescription': 'Range: Jul 1st 2022 to Oct 31st 2022.'
                        }
                    },

                    'yAxis': {
                        'title': {
                            'text': 'null'
                        }
                    },

                    'tooltip': {
                        'crosshairs': 'true',
                        'shared': 'true',
                        'valueSuffix': '°C'
                    },

                    'series': [
                        {
                            'name': 'Measures',
                            'data': averages,
                            'zIndex': 1,
                            'marker': {
                                'fillColor': 'red',
                                'lineWidth': 2,
                                }
                        },
                        {
                            'name': 'Measures',
                            'data': nominal,
                            'zIndex': 1,
                            'marker': {
                                'fillColor': 'black',
                                'lineWidth': 2,
                                }
                        },
                        {
                        'name': 'Range',
                        'data': ranges,
                        'type': 'arearange',
                        'lineWidth': 0,
                        'linkedTo': ':previous',
                        'fillOpacity': 0.3,
                        'zIndex': 0,
                        'marker': {
                            'enabled': 'false'
                            }
                        },

                        ]
                    })
        return response


@admin.register(EquipmentTestedUnitSummary)
class EquipmentTestedUnitAdmin(ExportActionMixin, admin.ModelAdmin):
    """_summary_

    Args:
        ExportActionMixin (_type_): _description_
        admin (_type_): _description_

    Returns:
        _type_: _description_
    """

    change_list_template = 'admin/equipment_summary_change_list.html'
    list_filter = filter_list

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response
        # Getting time range for dynamic time calculation
        date_from = dict(date=request.GET.get("start_time__range__gte_0", None), time=request.GET.get("start_time__range__gte_1", None))
        date_to = dict(date=request.GET.get("start_time__range__lte_0", None), time=request.GET.get("start_time__range__lte_1", None))
        # New Dataset processed with pandas
        dataset = qs.values('ict_name', 'test_time', 'start_time')

        # Creating dataframe
        dataframe = pd.DataFrame(dataset)
        my_timezone = pytz.timezone('America/Mexico_City')
        if dataframe.empty:
            return response
        dataframe['start_time'] = dataframe['start_time'].dt.tz_convert(my_timezone)
        dataframe['trunc_start_time'] = dataframe['start_time'].dt.floor('h')
        dataframe['trunc_start_time'] = dataframe['trunc_start_time'].dt.tz_convert(my_timezone)
        dataframe2 = dataframe.groupby(['ict_name', 'trunc_start_time'], as_index = False)
        dataframe3 = dataframe2.sum()
        dataframe3['utilization'] = (dataframe3['test_time']*100)/3600

        # Passing data to context
        response.context_data['df3'] = dataframe3

        # Creating query for general data
        dataset = list(qs.values('ict_name').annotate(pass_total=Count('ict_name',filter=Q(general_status='Pass')),fail_total=Count('ict_name',filter=Q(general_status='Fail')),total=Count('ict_name')).order_by('ict_name'))

        # Creating ICT names list
        ict_list = list({value['ict_name'] for value in dataset})

        # Formatting JSON for each card
        data = [dict(ict_name=value['ict_name'], data=dict(passed=value['pass_total'], failed=value['fail_total'], total=value['total'])) for value in dataset]

        # Adding yield data
        for value in data:
            try:
                value['data']['yield'] = "{0:.0%}".format(value['data']['passed']/value['data']['total'])
            except ZeroDivisionError:
                value['data']['yield'] = 0

        # Testing specific data function
        week_data = self.create_specific_queryset(qs, response)

        # Adding week data
        for value in zip(data,week_data):
            value[0]['data']['utilization'] = value[1]['data']

        # Creating dataset for general data
        general_data = list(qs.values('general_status').annotate(total=Count('general_status')).order_by('general_status'))
        if general_data:
            general_dict = dict(
                passed=general_data[1]['total'],
                failed=general_data[0]['total'],
                total=general_data[1]['total']+general_data[0]['total'],
                yields="{0:.0%}".format(general_data[1]['total']/(general_data[1]['total']+general_data[0]['total'])))

            # Creating general utilization
            dataset = list(qs.annotate(week=ExtractWeek('start_time')).values('week').annotate(total_test_time=Sum('test_time')).order_by('week'))
            for value in dataset:
                value['utilization'] = "{0:.0%}".format((value['total_test_time']/18)/86400)

            general_dict['utilization'] = dataset
            to_insert = dict(ict_name='General', data=general_dict)

            # Inserting general data
            data.insert(0, to_insert)

        # Passing data to context
        response.context_data['ict_list'] = ict_list
        response.context_data['by_general_status'] = data

        # New Dataset processed with pandas
        dataset = qs.values('ict_name', 'test_time', 'start_time')

        # Creating dataframe
        dataframe = pd.DataFrame(dataset)

        # Adding date columt
        dataframe['date'] = dataframe['start_time'].dt.date

        # Adding hour column
        dataframe['hour'] = dataframe['start_time'].dt.hour

        # Creating pivot table
        pivot = pd.pivot_table(dataframe, index=["ict_name",'date'], columns='hour', values='test_time', fill_value=0, aggfunc='sum')
        pivot = pivot.reset_index()
        table_list = [x for _, x in pivot.groupby(pivot['ict_name'])]
        formatted_table_list = []
        for table in table_list:
            formatted_table = self.format_tables(table)
            formatted_table_list.append(formatted_table.to_html(justify='center', classes='mystyle'))

        # Passing data to context
        response.context_data['table_test'] = formatted_table_list

        pivot2 = pd.pivot_table(dataframe, index=["ict_name",'date'], columns='hour', values='test_time', fill_value=0, aggfunc=self.utilization)
        pivot2 = pivot2.reset_index()

        table_list = [x for _, x in pivot2.groupby(pivot2['ict_name'])]
        formatted_table_list2 = []
        for table in table_list:
            formatted_table = self.format_tables(table)
            formatted_table_list2.append(formatted_table.to_html(justify='center', classes='mystyle'))

        full_list = list(zip(formatted_table_list, formatted_table_list2))
        formatted_full_list = []
        for value in full_list:
            formatted_full_list.append((value[0],value[1]))

        # Passing data to context
        response.context_data['table_test2'] = formatted_table_list2
        response.context_data['table_test3'] = formatted_full_list

        return response

    def format_tables(self, table):
        table = table.set_index('ict_name', 'date')
        return table

    def utilization(self, test_time):
        return "{0:.0%}".format(np.sum(test_time)/3600)

    def create_specific_queryset(self, qs, response):
        # Creating queryset for week
        dataset = list(qs.annotate(week=ExtractWeek('start_time')).values('week','ict_name').annotate(total_test_time=Sum('test_time')).order_by('ict_name'))
        # Creating dataframe for utilization
        df = pd.DataFrame(dataset)
        df1= pd.pivot_table(df, index="ict_name", columns='week', values='total_test_time', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        for value in dataset:
            value['utilization'] = "{0:.0%}".format(value['total_test_time']/518400)

        equipment_list = list({value['ict_name'] for value in dataset})
        equipment_list.sort()
        data = []
        for ict in equipment_list:
            equipment_data = [dict(week=value['week'], test_time=value['total_test_time'], utilization=value['utilization']) for value in dataset if value['ict_name'] == ict]
            data.append(dict(ict_name=ict, data=equipment_data))
        return data


@admin.register(MeasureSummary)
class MeasureSummaryAdmin(admin.ModelAdmin):

    change_list_template = 'admin/measure_summary_change_list.html'
    list_filter = [('serial__start_time', DateTimeRangeFilter),
                   'status',
                   ('serial__model_name', DropdownFilter),
                   ('serial__ict_name', DropdownFilter),
                   ('serial__fixture_name', DropdownFilter),
                   ]


    def filter_by_location(self, request_dict, location):
        request_dict['location'] = [location]
        # Cleaning dictionary
        request_dict = [(key,value[0]) for key,value in request_dict.items()]
        url=(
            reverse("admin:iyet_manager_measuresummary_changelist")
            + "?"
            + urlencode(request_dict)
        )
        return format_html('<a href="{}" target="_blank" rel="noopener noreferrer">{}</a>', url, location)

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        # Asserting queryset
        request_dict = dict(request.GET)
        try:
            assert request_dict['serial__start_time__range__gte_0']
        except (AssertionError, KeyError):
            return response

        # Asserting queryset
        try:
            assert request_dict['serial__model_name']
        except (AssertionError, KeyError):
            return response

        # =====================================================================
        # CPK Table
        # =====================================================================
        # Creating Dataframe
        measures_df = pd.DataFrame(qs.prefetch_related("tested_unit_measures")\
            .filter(status=True)\
            .values('serial__start_time','location','subtest','measure','nominal_value','high_limit', 'low_limit'))

        # Sorting Dataframe
        measures_df.sort_values(by=['serial__start_time', 'location', 'subtest'], inplace=True)
        measures_df['measures_mean'] = 0
        measures_df['standard_deviation'] = 0
        measures_df_grouped = measures_df.groupby(['location','subtest','nominal_value','high_limit','low_limit']).agg({
            'measure': ['mean', 'std',],
        })
        measures_df_grouped = measures_df_grouped.reset_index()
        measures_df_grouped.columns = [' '.join(col).strip() for col in measures_df_grouped.columns.values]
        measures_df_grouped['high cp'] = (measures_df_grouped['high_limit']-measures_df_grouped['measure mean'])/(3*measures_df_grouped['measure std'])
        measures_df_grouped['low cp'] = (measures_df_grouped['measure mean']-measures_df_grouped['low_limit'])/(3*measures_df_grouped['measure std'])
        measures_df_grouped['cpk'] = measures_df_grouped[['high cp', 'low cp']].min(axis=1)
        measures_df_grouped = measures_df_grouped.sort_values(by=['cpk'])

        measures_df_grouped['location'] = measures_df_grouped['location'].apply(lambda crd: self.filter_by_location(request_dict, crd))
        cpk_table = measures_df_grouped[['location', 'subtest','nominal_value', 'high_limit', 'low_limit','cpk']]
        cpk_table['cpk'] = cpk_table['cpk'].round(2)
        cpk_table['nominal_value'] = cpk_table['nominal_value'].apply(lambda x: Quantity(x).render())
        cpk_table['high_limit'] = cpk_table['high_limit'].apply(lambda x: Quantity(x).render())
        cpk_table['low_limit'] = cpk_table['low_limit'].apply(lambda x: Quantity(x).render())

        # Passing data to template
        response.context_data['CPK_table'] = cpk_table
        self.process_crd_measures(qs, response, request_dict['location'])
        return response


    def process_crd_measures(self, qs, response, crd):
        # Dataset for measures
        dataset = qs.values('serial__start_time','serial__model_name','location','measure','nominal_value','high_limit','low_limit')
        dataframe = pd.DataFrame(dataset)

        # Return response when DataFrame object is empty
        if dataframe.empty:
            return response
        dataframe = dataframe.sort_values(by='serial__start_time', ascending=False)
        dataframe['mean'] = dataframe['measure'].mean()
        print(dataframe)
        # Calculating CPK
        Cpk = min([(dataframe['high_limit'].iloc[-1]-dataframe['mean'].iloc[-1])/(3*dataframe['measure'].std()),(dataframe['mean'].iloc[-1]-dataframe['low_limit'].iloc[-1])/(3*dataframe['measure'].std())])
        response.context_data['high_limit'] = dataframe['high_limit'].iloc[-1]
        print(dataframe['high_limit'].iloc[-1])
        response.context_data['low_limit'] = dataframe['low_limit'].iloc[-1]
        print(dataframe['low_limit'].iloc[-1])

        # Passing data to template
        response.context_data['location'] = dataframe['location'].unique().tolist()[0]
        response.context_data['model'] = dataframe['serial__model_name'].unique().tolist()[0]
        response.context_data['measures'] = dataframe['measure'].tolist()
        response.context_data['mean'] = dataframe['measure'].mean()
        response.context_data['mean'] = dataframe['mean'].tolist()
        response.context_data['nominal_value'] = dataframe['nominal_value'].tolist()
        response.context_data['ranges'] = [list(value) for value in list(zip(dataframe['high_limit'].tolist(),dataframe['low_limit'].tolist()))]
        response.context_data['CPK'] = Cpk


@admin.register(Fixture)
class FixtureAdmin(admin.ModelAdmin):

    def probe_count(self, obj):
        count = obj.fixture.count()
        url=(
            reverse("admin:wpr_manager_pin_changelist")
            + "?"
            + urlencode({"q": f"{obj.equipment}"})
        )
        return format_html('<a href="{}">{} probes</a>', url, count)

    def wire_count(self, obj):
        count = obj.component_fixture.count()
        url=(
            reverse("admin:wpr_manager_component_changelist")
            + "?"
            + urlencode({"q": f"{obj.equipment.id}"})
        )
        return format_html('<a href="{}">{} wires</a>', url, count)

    @admin.display(description='Description')
    def fixture_description(self, obj):
        return obj.equipment.description

    @admin.display(description='Family', ordering='equipment__family')
    def fixture_family(self, obj):
        return obj.equipment.family

    list_display = ['equipment', 'model']


@admin.register(FixturePlotter)
class FixturePlotterAdmin(admin.ModelAdmin):
    change_list_template = 'admin/pin_plotter.html'
    list_filter = [
        ('serial__start_time', DateTimeRangeFilter),
        ('serial__general_status', DropdownFilter),
        ('serial__model_name', DropdownFilter),
        ('failure_type', DropdownFilter),
        ('serial__fixture_name', DropdownFilter),
        ]
    search_fields = ['location']

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        search_term_list = [crd.lower() for crd in search_term_list]
        query_condition = ' | '.join([f'Q(location{crd.lower()})' for crd in search_term_list])
        appended_queryset = queryset.filter(location__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        request_dict = dict(request.GET)
        try:
            qs = response.context_data['cl'].queryset
            assert request_dict['serial__fixture_name']
        except (AssertionError, AttributeError, KeyError):
            response.context_data['show_plotter'] = False
            response.context_data['message'] = 'Select a fixture in filters'
            return response

        # Querying IYET to get failing nodes
        try:
            fixture = Fixture.objects.get(equipment=request_dict['serial__fixture_name'][-1].lower().replace(" ","_").title())
        except (UnboundLocalError, Fixture.DoesNotExist, OperationalError):
            response.context_data['show_plotter'] = False
            response.context_data['message'] = """
                Fixture not created yet. Please upload fixture and wirelist files for
                plotter creation.
            """
            return response

        # Generating dataset for plotter
        if not qs:
            response.context_data['show_plotter'] = False
            response.context_data['message'] = """
                Empty query. Select another model, fixture or date range to get results.
            """
            return response

        top_side = list(Pin.objects.filter(fixture=fixture).values('fixture__model','x_coordinate', 'y_coordinate','node', 'probe').filter(side='TOP'))
        bottom_side = list(Pin.objects.filter(fixture=fixture).values('fixture__model','x_coordinate', 'y_coordinate','node', 'probe').filter(side='BOTTOM'))
        response.context_data['show_plotter'] = True
        response.context_data['fixture_name'] = fixture.equipment
        response.context_data['top_board_points'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, top_side)))
        response.context_data['bottom_board_points'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, bottom_side)))
        # Asserting queryset
        try:
            assert request_dict['serial__start_time__range__gte_0']
        except (AssertionError, KeyError):
            response.context_data['show_plotter'] = True
            messages.warning(request, 'Select dates to show WPR (Worst Probe Report).')
            response.context_data['message'] = """
                Select date range to show WPR (Worst Probe Report).
            """
            response.context_data['dirty_points_top'] = json.dumps(0)
            response.context_data['dirty_points_bottom'] = json.dumps(0)
            response.context_data['location_dirty_points_top'] = json.dumps(0)
            response.context_data['location_dirty_points_bottom'] = json.dumps(0)
            return response

        # Querying IYET to get failing nodes
        start_node_dataset = pd.DataFrame(qs.exclude(start_node='').values('serial__start_time', 'serial__serial_number', 'start_node', 'start_node_brc'))
        start_node_dataset_auziliar = pd.DataFrame(qs.values())
        print(start_node_dataset_auziliar)
        if not start_node_dataset.empty:
            start_node_dataset = start_node_dataset.drop_duplicates(subset=['serial__serial_number', 'serial__start_time', 'start_node_brc'])
            start_node_dataset = start_node_dataset.sort_values(by='start_node')
            start_node_dataset['start_node'].replace('', np.nan, inplace=True)
            start_node_dataset.dropna(subset=['start_node'], inplace=True)

            # Passing data to Highcharts
            dataset_top = list(Pin.objects.filter(fixture=fixture,node__in=start_node_dataset['start_node']).values('fixture__model','x_coordinate', 'y_coordinate','node','probe').filter(side='TOP'))
            dataset_bottom = list(Pin.objects.filter(fixture=fixture,node__in=start_node_dataset['start_node']).values('fixture__model','x_coordinate', 'y_coordinate','node','probe').filter(side='BOTTOM'))

            response.context_data['dirty_points_top'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, dataset_top)))
            response.context_data['dirty_points_bottom'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, dataset_bottom)))

            # Dataframe as table for node repetition count
            node_table = pd.DataFrame(start_node_dataset)
            node_table = node_table.groupby(['start_node', 'start_node_brc'], as_index=False).agg(total=pd.NamedAgg(column='start_node', aggfunc='count'))
            node_table = node_table.sort_values(by='total', ascending=False)

            # Converting locations to nodes from Wire model
            worst_nodes = Wire.objects\
            .filter(fixture=fixture,brc__in=start_node_dataset['start_node_brc'])\
            .values()
            nodes_dataset = pd.DataFrame(worst_nodes)
        else:
            messages.warning(request, 'Node dataset is empty.')
            nodes_dataset = pd.DataFrame()
            response.context_data['dirty_points_top'] = json.dumps(0)
            response.context_data['dirty_points_bottom'] = json.dumps(0)

        # Querying IYET to get failing locations and converting to nodes
        location_dataset = qs.exclude(location='').values('serial__start_time', 'serial__serial_number', 'location')
        location_dataset = pd.DataFrame(location_dataset)
        location_dataset = location_dataset.drop_duplicates(subset=['serial__serial_number', 'serial__start_time', 'location'])
        location_dataset = location_dataset.sort_values(by=['location'])
        location_dataset = location_dataset.loc[location_dataset['location']!='']

        # Grouping by location for node calculation
        df3 = location_dataset.groupby(['location'], as_index=False).agg(total=pd.NamedAgg(column='location', aggfunc='count')).sort_values(by='total',ascending=False)

        # Converting locations to nodes from Wire model
        worst_pins = Wire.objects\
            .filter(fixture=fixture,location__in=location_dataset['location'])\
            .values()

        # Converting to dataframe to get only one column (to refactor)
        locations_nodes_dataset = pd.DataFrame(worst_pins)
        full_data = pd.merge(df3,locations_nodes_dataset,on='location')
        full_data.drop(columns=['id','fixture_id'], inplace=True)
        full_data = full_data[['location','test','node','brc','total']]
        full_data.set_index(['node', 'brc', 'location'], inplace=True)
        full_data.reset_index(inplace=True)
        full_data = full_data.groupby(['node', 'brc'], as_index=False).agg(total=pd.NamedAgg(column='total', aggfunc='sum')).sort_values(by='total',ascending=False)
        locations_nodes_dataset.sort_values(by=['location', 'node', 'brc'], inplace=True)
        locations_nodes_dataset_nodes = [value.upper() for value in locations_nodes_dataset['node']]
        
        worst_pins_to_plot_top = list(Pin.objects.filter(fixture=fixture,node__in=locations_nodes_dataset_nodes).values('fixture__model','x_coordinate', 'y_coordinate','node','probe').filter(side='TOP'))
        worst_pins_to_plot_top = [value for value in worst_pins_to_plot_top if value['node'] != 'GND']
        worst_pins_to_plot_bottom = list(Pin.objects.filter(fixture=fixture,node__in=locations_nodes_dataset_nodes).values('fixture__model','x_coordinate', 'y_coordinate','node','probe').filter(side='BOTTOM'))
        print(worst_pins_to_plot_bottom)
        worst_pins_to_plot_bottom = [value for value in worst_pins_to_plot_bottom if value['node'] != 'GND']
        worst_pins_to_plot_top_df = pd.DataFrame(worst_pins_to_plot_top)
        worst_pins_to_plot_bottom_df = pd.DataFrame(worst_pins_to_plot_bottom)
        print(worst_pins_to_plot_top_df)
        print(worst_pins_to_plot_bottom_df)
        
        response.context_data['location_dirty_points_top'] = json.dumps(list(map(lambda row: {'name': row['node'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, worst_pins_to_plot_top)))
        response.context_data['location_dirty_points_bottom'] = json.dumps(list(map(lambda row: {'name': row['node'], 'x': row['x_coordinate'], 'y': row['y_coordinate']}, worst_pins_to_plot_bottom)))
        
        if not location_dataset.empty and not start_node_dataset.empty:
            ...
            # Merging both dataframes to get wpr table
            dataframes = [locations_nodes_dataset, nodes_dataset]
            wpr_dataframe = pd.concat(dataframes)
            wpr_dataframe = wpr_dataframe.groupby(['brc', 'node']).agg(total=pd.NamedAgg(column='brc', aggfunc='count')).sort_values(by='total',ascending=False).reset_index()
            response.context_data['WPR'] = wpr_dataframe.head(20)
        else:
            response.context_data['empty_location_dataset'] = True
            response.context_data['empty_start_node_dataset'] = True
            response.context_data['message'] = """No Locations nor Nodes detected as failures. Try with another time range or
            select another fixture"""
            response.context_data['dirty_points'] = json.dumps(0)
            response.context_data['location_dirty_points'] = json.dumps(0)

        return response


@admin.register(UpgradedFixturePlotter)
class UpgradedFixturePlotterAdmin(admin.ModelAdmin):
    change_list_template = 'admin/pin_plotter_upgraded.html'
    list_filter = [
        ('serial__start_time', DateTimeRangeFilter),
        ('serial__general_status', DropdownFilter),
        ('serial__part_number', DropdownFilter),
        ('serial__model_name', DropdownFilter),
        ('failure_type', DropdownFilter),
        ('serial__ict_name', DropdownFilter),
        ('serial__fixture_name', DropdownFilter),
        ]
    search_fields = ['location']

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        query_condition = ' | '.join([f'Q(location{crd})' for crd in search_term_list])
        appended_queryset = queryset.filter(location__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        request_dict = dict(request.GET)
        try:
            qs = response.context_data['cl'].queryset
            assert request_dict['serial__fixture_name']
        except (AssertionError, AttributeError, KeyError):
            response.context_data['show_plotter'] = False
            response.context_data['message'] = 'Select a fixture in filters'
            return response

        # Querying IYET to get failing nodes
        try:
            equipment = request_dict['serial__fixture_name'][-1].lower().replace(" ","_").title()
            fixture = Fixture.objects.get(equipment=equipment)
        except (UnboundLocalError, Fixture.DoesNotExist, OperationalError):
            response.context_data['show_plotter'] = False
            response.context_data['message'] = f"""
                Fixture {equipment} not created yet. Please upload fixture and wirelist files for
                plotter creation.
            """
            return response

        # Generating dataset for plotter
        if not qs:
            response.context_data['show_plotter'] = False
            response.context_data['message'] = """
                Empty query. Select another model, fixture or date range to get results.
            """
            return response

        top_side = list(UpgradedPin.objects.filter(fixture=fixture).values('fixture__model','probe_x_coordinate', 'probe_y_coordinate','node', 'probe').filter(side='TOP'))
        bottom_side = list(UpgradedPin.objects.filter(fixture=fixture).values('fixture__model','probe_x_coordinate', 'probe_y_coordinate','node', 'probe').filter(side='BOTTOM'))
        response.context_data['show_plotter'] = True
        response.context_data['fixture_name'] = fixture.equipment
        response.context_data['top_board_points'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['probe_x_coordinate'], 'y': row['probe_y_coordinate']}, top_side)))
        response.context_data['bottom_board_points'] = json.dumps(list(map(lambda row: {'name': row['node'], 'probe': row['probe'], 'x': row['probe_x_coordinate'], 'y': row['probe_y_coordinate']}, bottom_side)))
        # Asserting queryset
        try:
            assert request_dict['serial__start_time__range__gte_0']
        except (AssertionError, KeyError):
            response.context_data['show_plotter'] = True
            messages.warning(request, 'Select dates to show WPR (Worst Probe Report).')
            response.context_data['message'] = """
                Select date range to show WPR (Worst Probe Report).
            """
            response.context_data['dirty_points_top'] = json.dumps(0)
            response.context_data['dirty_points_bottom'] = json.dumps(0)
            response.context_data['location_dirty_points_top'] = json.dumps(0)
            response.context_data['location_dirty_points_bottom'] = json.dumps(0)
            return response
        
        """
            Starting refactoring process. WPR list shows Probe, node and device but
            in general, main data is about probes. Dataframes will be refactored
            taking this in account.
        """
        # Querying IYET to get nodes (by start_brc field)
        start_node_dataset = pd.DataFrame(qs.exclude(start_node='').values('serial__start_time', 'serial__serial_number', 'start_node', 'start_node_brc'))
        if not start_node_dataset.empty:
            start_node_dataset.drop_duplicates(subset=['serial__serial_number', 'serial__start_time', 'start_node_brc'], inplace=True)
            start_node_dataset['start_node'].replace('', np.nan, inplace=True)
            start_node_dataset.dropna(subset=['start_node'], inplace=True)
            start_node_dataset.sort_values(by='start_node', inplace=True)

            # Converting locations to nodes from Wire model
            worst_nodes = Wire.objects\
            .filter(fixture=fixture,brc__in=start_node_dataset['start_node_brc'])\
            .values()
            nodes_dataset = pd.DataFrame(worst_nodes)
        else:
            messages.warning(request, 'No node data retrieved from query.')
            nodes_dataset = pd.DataFrame()

        # Querying IYET to get failing locations and converting to nodes
        location_dataset = qs.exclude(location='').values('serial__start_time', 'serial__serial_number', 'location')
        location_dataset = pd.DataFrame(location_dataset)
        if not location_dataset.empty:
            location_dataset.drop_duplicates(subset=['serial__serial_number', 'serial__start_time', 'location'], inplace=True)
            location_dataset.sort_values(by=['location'], inplace=True)
            location_dataset['location'].replace('', np.nan, inplace=True)
            location_dataset.dropna(subset=['location'], inplace=True)

            # Converting locations to nodes from Wire model
            worst_pins = Wire.objects\
                .filter(fixture=fixture,location__in=location_dataset['location'])\
                .values()
            locations_dataset = pd.DataFrame(worst_pins)
            # Converting to dataframe to get only one column (to refactor)
            locations_nodes_dataset = pd.DataFrame(worst_pins)
            locations_nodes_dataset.sort_values(by=['location', 'node', 'brc'], inplace=True)
        else:
            messages.warning(request, 'No location data retrieved from query.')
            locations_dataset = pd.DataFrame()

        wire_dfs = [nodes_dataset, locations_dataset]
        wirelist_df = pd.concat(wire_dfs)
        print(wirelist_df)
        locations_nodes_dataset_brc = wirelist_df['brc'].to_list()
        
        worst_pins_to_plot_top = list(UpgradedPin.objects.filter(Q(start_brc__in=locations_nodes_dataset_brc)|Q(end_brc__in=locations_nodes_dataset_brc), fixture=fixture).values('fixture__model','probe_x_coordinate', 'probe_y_coordinate','node','probe').filter(side='TOP'))
        print(worst_pins_to_plot_top)
        worst_pins_to_plot_top = [value for value in worst_pins_to_plot_top]
        worst_pins_to_plot_bottom = list(UpgradedPin.objects.filter(Q(start_brc__in=locations_nodes_dataset_brc)|Q(end_brc__in=locations_nodes_dataset_brc), fixture=fixture).values('fixture__model','probe_x_coordinate', 'probe_y_coordinate','node','probe').filter(side='BOTTOM'))
        print(worst_pins_to_plot_bottom)
        worst_pins_to_plot_bottom = [value for value in worst_pins_to_plot_bottom]

        # Dataframe as WPR from ICT
        wpr_df = pd.DataFrame(UpgradedPin.objects\
            .filter(Q(start_brc__in=locations_nodes_dataset_brc)|Q(end_brc__in=locations_nodes_dataset_brc), fixture=fixture)\
            .values('probe', 'node', 'start_brc'))
        wpr_df = wpr_df.groupby(['probe','node'], as_index=False).agg(total=pd.NamedAgg(column='probe', aggfunc='count')).sort_values(by='total', ascending=False)
        # wpr_df.sort_values(by=['count'], ascending=False, inplace=True)
        # wpr_df.drop(columns=['start_brc'], inplace=True)
        response.context_data['WPR'] = wpr_df

        response.context_data['wpr_points_top'] = json.dumps(list(map(lambda row: {'name': row['node'], 'x': row['probe_x_coordinate'], 'y': row['probe_y_coordinate']}, worst_pins_to_plot_top)))
        response.context_data['wpr_points_bottom'] = json.dumps(list(map(lambda row: {'name': row['node'], 'x': row['probe_x_coordinate'], 'y': row['probe_y_coordinate']}, worst_pins_to_plot_bottom)))
        return response


@admin.register(NDFFixturePlotter)
class NDFFixturePlotterAdmin(admin.ModelAdmin):
    change_list_template = 'admin/ndf_plotter.html'
    list_filter = [
        ('fixture__model', DropdownFilter),
        ]
    search_fields = ['location']

    def get_search_results(self, request, queryset, search_term):
        search_term_list = search_term.split(' ')
        search_term_list = [crd.lower() for crd in search_term_list]
        appended_queryset = queryset.filter(location__in=search_term_list)
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        queryset |= appended_queryset
        return queryset, use_distinct

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request,extra_context=extra_context)
        request_dict = dict(request.GET)
        try:
            qs = response.context_data['cl'].queryset
            assert request_dict['fixture__model']
        except (AssertionError, AttributeError, KeyError):
            response.context_data['show_plotter'] = False
            messages.warning(request,'Select fixture model in filters')
            return response

        try:
            fixture = Fixture.objects.filter(model=request_dict['fixture__model'][-1]).first()
            print(fixture)
        except (UnboundLocalError, Fixture.DoesNotExist, OperationalError):
            response.context_data['show_plotter'] = False
            messages.warning(request,"""
                Fixture not created yet. Please upload fixture and wirelist files for
                plotter creation.
            """)
            return response

        top_side = list(Pin.objects.filter(fixture=fixture).values('fixture__model','x_coordinate', 'y_coordinate','node', 'probe').filter(side='TOP'))
        bottom_side = list(Pin.objects.filter(fixture=fixture).values('fixture__model','x_coordinate', 'y_coordinate','node', 'probe').filter(side='BOTTOM'))
        response.context_data['show_plotter'] = True
        response.context_data['fixture_name'] = fixture.model
        response.context_data['top_board_points'] = json.dumps(list(map(lambda row: [row['x_coordinate'],row['y_coordinate']], top_side)))
        response.context_data['bottom_board_points'] = json.dumps(list(map(lambda row: [row['x_coordinate'],row['y_coordinate']], bottom_side)))
        
        # Passing crds from queryset
        try:
            assert request_dict['q']
            assert request_dict['q'] != ''
        except (AssertionError, KeyError):
            messages.warning(request, "Place in search bar CRDs flagged as NDF")
            response.context_data['custom_search'] = json.dumps(0)
            return response
        crds = pd.DataFrame(qs.values())
        if crds.empty:
            messages.warning(request, "One or more CRDs from search doesn't belong to model.")
            response.context_data['custom_search'] = json.dumps(0)
            return response
        crds.drop_duplicates(subset=['location','node'], inplace=True)
        custom_search = list(UpgradedPin.objects.filter(Q(start_brc__in=crds['brc'].to_list())|Q(end_brc__in=crds['brc'].to_list()),fixture=fixture).values('fixture__model','probe_x_coordinate', 'probe_y_coordinate','node', 'probe'))
        response.context_data['custom_search'] = json.dumps(list(map(lambda row: [row['probe_x_coordinate'],row['probe_y_coordinate']], custom_search)))
        return response


@admin.register(Pin)
class PinAdmin(admin.ModelAdmin):
    list_display = ['probe', 'node', 'x_coordinate', 'y_coordinate', 'fixture']
    list_filter = ['fixture']
    search_fields = ['node']


@admin.register(UpgradedPin)
class UpgradedPinAdmin(admin.ModelAdmin):
    search_fields = ['node']


@admin.register(Wire)
class WireAdmin(admin.ModelAdmin):
    list_filter = ['fixture', 'test', 'location']
    list_display = ['test', 'location', 'node', 'brc', 'fixture']
    search_fields = ['node', 'location']


@admin.register(Measure)
class MeasureAdmin(ExportActionMixin, admin.ModelAdmin):
    list_display = ['serial',
                    'location',
                    'subtest',
                    'status',
                    'measure',
                    'nominal_value',
                    'high_limit',
                    'low_limit',
                    ]

    list_filter = ['status',
                   ('serial__model_name', DropdownFilter),
                   ('location', DropdownFilter),
                   ]

    def get_queryset(self, request):
        return super().get_queryset(request).prefetch_related('serial')


@admin.register(TaktTimeDashboard)
class TaktTimeAdmin(admin.ModelAdmin):
    change_list_template = 'admin/takt_time_dashboard.html'
    list_filter = [('start_time', DateTimeRangeFilter),
                   ('ict_name', DropdownFilter)
                   ]

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AssertionError, AttributeError, KeyError):
            return response
        if not qs:
            return response
        takt_dataset = qs.values('start_time', 'test_time', 'general_status')
        takt_dataframe = pd.DataFrame(takt_dataset)
        takt_dataframe.sort_values(by='start_time',inplace=True)
        takt_dataframe.replace('Pass',1,inplace=True)
        takt_dataframe.replace('Fail',0,inplace=True)
        takt_dataframe['test_time'] = pd.to_timedelta(takt_dataframe['test_time'], unit='s')
        takt_dataframe['end_time'] = takt_dataframe['start_time'] + takt_dataframe['test_time']
        # Cleaning Data
        takt_dataframe.drop_duplicates(subset=['start_time', 'test_time', 'general_status'], inplace=True)
        takt_dataframe_w_missing_time = takt_dataframe
        takt_dataframe_w_missing_time['next_time'] = takt_dataframe_w_missing_time['start_time'].shift(-1)
        takt_dataframe_w_missing_time['handling_time'] = takt_dataframe_w_missing_time['next_time'] - takt_dataframe_w_missing_time['end_time']
        new_rows = []
        for index, row in takt_dataframe_w_missing_time.iterrows():
            new_start_time = row.end_time
            new_test_time = row.handling_time
            new_general_status = 2
            new_end_time = new_start_time + new_test_time
            new_next_time = 0
            new_handling_time = 0
            new_row = dict(start_time=new_start_time,
                           test_time=new_test_time,
                           general_status=new_general_status,
                           end_time=new_end_time,
                           next_time = new_next_time,
                           handling_time=new_handling_time)
            new_rows.append(new_row)
        more_data = pd.DataFrame(new_rows)
        takt_dataframe_w_missing_time = pd.concat([takt_dataframe_w_missing_time, more_data]).sort_values(by='start_time')
        takt_dataframe_w_missing_time.drop(columns=['next_time', 'handling_time'], inplace=True)
        takt_dataframe_w_missing_time.drop(columns=['test_time'], inplace=True)
        takt_dataframe_w_missing_time = takt_dataframe_w_missing_time[['start_time', 'end_time', 'general_status']]
        takt_dataframe_w_missing_time.columns = ['x','x2','colorIndex']
        takt_dataframe_w_missing_time['y'] = 0
        handling_time_df = takt_dataframe_w_missing_time.loc[takt_dataframe_w_missing_time['colorIndex']==2]
        handling_time_df['elapsed_time'] = handling_time_df['x2'] - handling_time_df['x']
        total_takt_time = handling_time_df['elapsed_time'].sum()
        average_takt_time = handling_time_df['elapsed_time'].mean().total_seconds()
        std_takt_time = handling_time_df['elapsed_time'].std().total_seconds()
        response.context_data['total_takt_time'] = total_takt_time
        response.context_data['average_takt_time'] = average_takt_time
        response.context_data['std_takt_time'] = std_takt_time
        data = takt_dataframe_w_missing_time.to_json(orient='records')
        response.context_data['tested_unit'] = data
        return response
