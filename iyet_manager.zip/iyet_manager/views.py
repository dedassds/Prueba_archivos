import datetime
import re
import string
from datetime import timedelta
from typing import Any

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.auth.models import User
from django.db import transaction
from django.db.models import Count
from django.db.models.functions import ExtractHour
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView

import pandas as pd
import pytz
from pytz import timezone
from rest_framework import viewsets
import numpy as np

from Website.settings.base import MEDIA_ROOT

from .filters import TestedUnitFilter
from .forms import FixtureForm
from .models import Fixture, FixturePlotter, IYETTestedUnit, Pin, TestedUnit, Wire, UpgradedPin
from .serializers import TestedUnitSerializer


# Create your views here.
class TestedUnitViewSet(viewsets.ModelViewSet):
    queryset = TestedUnit.objects.all()
    serializer_class = TestedUnitSerializer
    http_method_names = ['get', 'post', 'retrieve', 'put', 'patch']


class DashboardView(ListView):

    series_6 = ['FGNICT23',
                'FGNICT17',
                'FGNICT22',
                'FGNICT16',
                'FGNICT18',
                'FGNICT15',
                'FGNICT20',
                'FGNICT19',
                'FGNICT07']

    series_5 = ['FGNICT13',
                'FGNICT05',
                'FGNICT14',
                'FGNICT12',]

    series_3 = ['FGNICT01',
                'FGNICT02',
                'FGNICT10',
                'FGNICT08',
                'FGNICT11',
                'FGNICT24',
                'FGNICT25',
                'FGNICT06',
                'FGNICT09',
                ]
    model = TestedUnit
    template_name = 'iyet_manager/dashboard.html'

    def get_queryset(self):
        queryset = super().get_queryset()
        end_time = datetime.datetime.now(pytz.timezone('America/Mexico_City')) - timedelta(hours=8)
        ict_dataset = queryset\
            .filter(start_time__gte=end_time)\
            .annotate(hour=ExtractHour('start_time'),total=Count('general_status'))\
            .values('start_time', 'hour', 'ict_name', 'fixture_name', 'general_status', 'total', 'test_time', 'model_name', 'family_name')
        ict_dataset = TestedUnitFilter(self.request.GET, ict_dataset)
        return ict_dataset.qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        ict_dataset = self.get_queryset()
        ict_dataframe = pd.DataFrame(ict_dataset)
        if ict_dataframe.empty:
            return context
        ict_dataframe = ict_dataframe.sort_values(by='start_time')
        ict_dataframe = ict_dataframe.loc[ict_dataframe['hour']>datetime.datetime.now().hour-8]

        # Retrieving hours as categories for charts
        categories = ict_dataframe['hour'].unique().tolist()
        categories.sort()

        # Creating auxiliar dataframes
        test_time_dataframe = ict_dataframe.groupby(['ict_name'], as_index=False).agg(total=pd.NamedAgg(column='test_time', aggfunc='sum'))
        model_dataframe = ict_dataframe.groupby('ict_name',as_index=False)['model_name'].last()
        fixture_dataframe = ict_dataframe.groupby('ict_name',as_index=False)['fixture_name'].last()
        fixture_dataframe = fixture_dataframe.fillna('Missing')

        # Creating pivot table for hour data calculation
        df2= pd.pivot_table(ict_dataframe, index=['ict_name','general_status'], columns=['hour'], values='total', fill_value=0, aggfunc='sum', margins=True, margins_name='Total')
        df = pd.DataFrame(df2.to_records())

        # Creating sub dataframes
        ict_list = list(df['ict_name'].unique())
        ict_dataframe_list = [df.loc[df['ict_name']==value] for value in ict_list]
        ict_dataframe_list = ict_dataframe_list[:-1]
        ict_data_list = []

        for ict in  ict_dataframe_list:
            ict_data = {}
            ict_data['name'] = ict['ict_name'].unique()[0]

            # Calculating passed units
            try:
                ict_data['passed_units'] = ict.loc[ict['general_status']=='Pass',['Total']]['Total'].tolist()[-1]
            except IndexError:
                ict_data['passed_units'] = 0

            # Calculating passed units
            try:
                ict_data['failed_units'] = ict.loc[ict['general_status']=='Fail',['Total']]['Total'].tolist()[-1]
            except IndexError:
                ict_data['failed_units'] = 0
            ict_data['tested_units'] = ict_data['passed_units'] + ict_data['failed_units']

            # Calculating yield
            try:
                calculated_yield = ict_data['passed_units'] / ict_data['tested_units']
                if calculated_yield < .75:
                    ict_data['alert'] = 'danger'
                elif .75 < calculated_yield < .85:
                    ict_data['alert'] = 'warning'
                ict_data['yield'] = "{0:.2%}".format(calculated_yield)
            except ZeroDivisionError:
                ict_data['yield'] = 0

            # Calculating utilization
            try:
                ict_data['utilization'] = test_time_dataframe.loc[test_time_dataframe['ict_name']==ict_data['name'],['total']]['total'].tolist()[0] / (3600*(len(categories)-1))
                ict_data['utilization'] = "{0:.2%}".format(ict_data['utilization'])
            except (ZeroDivisionError,IndexError):
                ict_data['utilization'] = 0

            # Retrieving running models and fixtures
            ict_data['running_model'] = model_dataframe.loc[model_dataframe['ict_name']==ict_data['name'],['model_name']]['model_name'].tolist()[0]
            ict_data['current_fixture'] = fixture_dataframe.loc[fixture_dataframe['ict_name']==ict_data['name'],['fixture_name']]['fixture_name'].tolist()[0]

            # Retrieving passed units by hour
            try:
                passed_units_by_hour = ict.loc[ict['general_status']=='Pass']
                passed_units_by_hour = passed_units_by_hour.drop(columns=['ict_name','general_status','Total'])
                passed_units_by_hour = passed_units_by_hour.T
                passed_units_by_hour.columns = ['tested_units']
                ict_data['passed_units_by_hour'] = passed_units_by_hour['tested_units'].tolist()
            except (IndexError, ValueError):
                ict_data['passed_units_by_hour'] = [0] * len(categories)

            # Retrieving failed units by hour
            try:
                failed_units_by_hour = ict.loc[ict['general_status']=='Fail']
                failed_units_by_hour = failed_units_by_hour.drop(columns=['ict_name','general_status','Total'])
                failed_units_by_hour = failed_units_by_hour.T
                failed_units_by_hour.columns = ['tested_units']
                ict_data['failed_units_by_hour'] = failed_units_by_hour['tested_units'].tolist()
            except (IndexError, ValueError):
                ict_data['failed_units_by_hour'] = [0] * len(categories)

            # Calculating tested units by hour
            ict_data['tested_units_by_hour'] = []
            for passed,failed in zip(ict_data['passed_units_by_hour'],ict_data['failed_units_by_hour']):
                result = passed+failed
                ict_data['tested_units_by_hour'].append(result)

            # Creating status
            ict_data['status'] = 'Running'
            if ict_data['tested_units_by_hour'][-1] == 0:
                ict_data['status'] = 'Stopped'

            # Passing model
            ict_data['ict_model'] = 'series_6'
            if ict_data['name'] in self.series_3:
                ict_data['ict_model'] = 'series_3'
            elif ict_data['name'] in self.series_5:
                ict_data['ict_model'] = 'series_5'

            # Calculating yield by hour
            ict_data['yield_by_hour'] = []
            for index in range(len(ict_data['tested_units_by_hour'])):
                try:
                    result = ict_data['passed_units_by_hour'][index] / ict_data['tested_units_by_hour'][index]
                    result = result*100
                    ict_data['yield_by_hour'].append(result)
                except ZeroDivisionError:
                    ict_data['yield_by_hour'].append(0)
            ict_data_list.append(ict_data)

        # Passing data to template as context
        context['ict_data'] = ict_data_list
        context['categories'] = categories
        context['expected_yield'] = [85] * len(categories)
        ict_names_list = df['ict_name'].unique().tolist()[:-1]
        model_list = ict_dataframe['model_name'].unique().tolist()
        family_list = ict_dataframe['family_name'].unique().tolist()
        context['ict_names_list'] = ict_names_list
        context['model_list'] = model_list
        context['family_list'] = family_list
        context['tested_unit_filter'] = TestedUnitFilter(self.request.GET, ict_dataset)
        return context


class FixtureBaseView(LoginRequiredMixin, View):
    model = Fixture
    success_url = reverse_lazy('homeapp:home')


class FixtureCreateView(FixtureBaseView, CreateView):
    form_class = FixtureForm

    def form_valid(self, form):
        obj = form.save(commit=False)
        obj.save()
        to_create_fixture = self.convert_fixture(obj)
        to_create_op_fixture = self.create_op_fixture(obj)
        to_create_wirelist = self.convert_wirelist(obj)
        Processor.create(self, to_create_fixture, to_create_wirelist, to_create_op_fixture)
        return super(FixtureCreateView, self).form_valid(form)

    def create_op_fixture(self, instance):
        nodes = []
        file_path = MEDIA_ROOT / 'wpr_manager' / instance.equipment / 'fixture' / f'{instance.model}_fixture'
        with open(file_path, 'r') as fixture:
            for result in re.finditer(r'NODE\s+(?P<node_name>[\S]+)(?P<node_data>[\s\S]*?)(?=\n\n)', fixture.read(), re.MULTILINE):
                try:
                    assert result
                except AssertionError:
                    continue
                nodes.append(result.groupdict())
        for node in nodes:
            node_data = node.pop('node_data')
            # Capturing brcs
            for brcs in re.finditer(r'\s+PINS\n+(?P<brcs>[\s\S]*?)(?=\s+WIRES|\s+PROBES)', node_data, re.MULTILINE):
                try:
                    assert brcs
                except AssertionError:
                    continue
            node['brcs'] = [int(match) for match in re.findall(r"\s+(?P<brc>[0-9]+).+", brcs.group(0))]

            # Capturing probes
            probe_list = []
            for probe_data in re.finditer(r'\s+PROBES\n+(?P<probes>[\s\S]*?)(?=\s+WIRES|\s+TRANSFERS|\s+ALTERNATES)', node_data, re.MULTILINE):
                try:
                    assert probe_data
                except AssertionError:
                    continue
                probe_list = [probe.groupdict() for probe in re.finditer(r"\s+(?P<probe>P\d+)\s+(?P<x_point>-?\d+),\s+(?P<y_point>-?\d+)\s+(?P<extra_data>[^;]+)", probe_data.group(0))]
            node['probes'] = probe_list

            # Capturing transfers
            transfer_list = []
            for transfers_data in re.finditer(r'\s+TRANSFERS\n+(?P<transfers>[\s\S]*?)(?=\s+WIRES)', node_data, re.MULTILINE):
                try:
                    assert transfers_data
                except AssertionError:
                    transfer_list = []
                    continue
                transfer_list = [transfer.groupdict() for transfer in re.finditer(r"\s+(?P<transfer>T\d+)\s+(?P<x_point>-?\d+),\s+(?P<y_point>-?\d+)", transfers_data.group(0))]
            node['transfers'] = transfer_list

            # Capturing wires
            wires_list = []
            for wires_data in re.finditer(r'WIRES\n(?P<wires>[\s\S]*)', node_data, re.MULTILINE):
                try:
                    assert wires_data
                except AssertionError:
                    continue
                wires_list = [{key:value for key, value in wire.groupdict().items() if value is not None} for wire in re.finditer(r"\s+(?:(?P<start_brc>\d+)|(?P<start_transfer>T\d+))\s+TO\s+(?:(?P<end_brc>\d+)|(?P<end_transfer>T\d+)|(?P<probe>P\d+)|(?P<terminal>TERMINAL))", wires_data.group(0))]
            node['wires'] = wires_list
        brcs_df = pd.json_normalize(nodes,
                                    record_path=['brcs'],
                                    meta=['node_name'])
        probes_df = pd.json_normalize(nodes,
                                    record_path=['probes'],
                                    meta=['node_name'])
        transfers_df = pd.json_normalize(nodes,
                                    record_path=['transfers'],
                                    meta=['node_name'])
        # Working over this dataframe to complement connections with the other ones
        wires_df = pd.json_normalize(nodes,
                                    record_path=['wires'],
                                    meta=['node_name'])
        probes_wires_df = pd.merge(probes_df, wires_df, on='probe', how='outer')
        probes_wires_df['node_name_x'].fillna(probes_wires_df['node_name_y'], inplace=True)
        probes_wires_df.drop(columns=['node_name_y'], inplace=True)
        wires_df_end_transfer = wires_df.loc[wires_df['end_transfer'].notna()]
        probes_wires_df = probes_wires_df.merge(wires_df_end_transfer, left_on='start_transfer', right_on='end_transfer', how='outer')
        probes_wires_df = probes_wires_df[['node_name',
                                        'node_name_x',
                                        'start_brc_x',
                                        'start_brc_y',
                                        'probe_x',
                                        'probe_y',
                                        'start_transfer_x',
                                        'start_transfer_y',
                                        'end_transfer_x',
                                        'end_transfer_y',
                                        'terminal_x',
                                        'terminal_y',
                                        'end_brc_x',
                                        'end_brc_y',
                                        'x_point',
                                        'y_point',
                                        'extra_data']]
        probes_wires_df['node_name'].fillna(probes_wires_df['node_name_x'], inplace=True)
        probes_wires_df['start_brc_x'].fillna(probes_wires_df['start_brc_y'], inplace=True)
        probes_wires_df['probe_x'].fillna(probes_wires_df['probe_y'], inplace=True)
        probes_wires_df['start_transfer_x'].fillna(probes_wires_df['start_transfer_y'], inplace=True)
        probes_wires_df['end_transfer_x'].fillna(probes_wires_df['end_transfer_y'], inplace=True)
        probes_wires_df['terminal_x'].fillna(probes_wires_df['terminal_y'], inplace=True)
        probes_wires_df['end_brc_x'].fillna(probes_wires_df['end_brc_y'], inplace=True)
        probes_wires_df.drop(columns=['node_name_x',
                                    'start_brc_y',
                                    'probe_y',
                                    'start_transfer_y',
                                    'end_transfer_x',
                                    'end_transfer_y',
                                    'terminal_y',
                                    'end_brc_y'], inplace=True)
        probes_wires_df.columns = ['node_name',
                                'start_brc',
                                'probe',
                                'start_transfer',
                                'terminal',
                                'end_brc',
                                'x_point',
                                'y_point',
                                'extra_data']
        wires_df_end_brc = wires_df.loc[wires_df['end_brc'].notna()]
        probes_wires_df = probes_wires_df.merge(probes_wires_df.dropna(subset=['start_brc']), left_on='end_brc', right_on='start_brc', how='left')
        probes_wires_df['node_name_x'].fillna(probes_wires_df['node_name_y'], inplace=True)
        probes_wires_df['probe_x'].fillna(probes_wires_df['probe_y'], inplace=True)
        probes_wires_df['start_transfer_x'].fillna(probes_wires_df['start_transfer_y'], inplace=True)
        probes_wires_df['terminal_x'].fillna(probes_wires_df['terminal_y'], inplace=True)
        probes_wires_df['x_point_x'].fillna(probes_wires_df['x_point_y'], inplace=True)
        probes_wires_df['y_point_x'].fillna(probes_wires_df['y_point_y'], inplace=True)
        probes_wires_df['extra_data_x'].fillna(probes_wires_df['extra_data_y'], inplace=True)
        probes_wires_df.drop(columns=['node_name_y',
                                'probe_y',
                                'start_transfer_y',
                                'terminal_y',
                                'x_point_y',
                                'y_point_y',
                                'extra_data_y',
                                'start_brc_y',
                                'end_brc_y'], inplace=True)
        probes_wires_df.columns = ['node_name',
                                'start_brc',
                                'probe',
                                'transfer',
                                'terminal',
                                'end_brc',
                                'x_point',
                                'y_point',
                                'extra_data']
        probes_wires_df["brc_duplicated_in_node"] = probes_wires_df["start_brc"][~probes_wires_df["start_brc"].isin(probes_wires_df["end_brc"])]
        probes_wires_df.dropna(subset=['brc_duplicated_in_node'], inplace=True)
        probes_wires_df.drop(columns=['brc_duplicated_in_node'], inplace=True)
        probes_wires_df = pd.merge(probes_wires_df, transfers_df[['transfer','x_point', 'y_point']], on='transfer', how='left')
        probes_wires_df.dropna(subset=['probe','terminal'], how='all', inplace=True)
        probes_wires_df.loc[probes_wires_df['extra_data'].str.contains('50MIL', na=False), 'center'] = '50MIL'
        probes_wires_df.loc[probes_wires_df['extra_data'].str.contains('75MIL', na=False), 'center'] = '75MIL'
        probes_wires_df.loc[probes_wires_df['extra_data'].str.contains('TOP', na=False), 'side'] = 'TOP'
        probes_wires_df['side'] = probes_wires_df['side'].fillna('BOTTOM')
        probes_wires_df = probes_wires_df.rename(columns={'x_point_x': 'probe_x_coordinate',
                                                        'y_point_x': 'probe_y_coordinate',
                                                        'x_point_y': 'transfer_x_coordinate',
                                                        'y_point_y': 'transfer_y_coordinate',
                                                        'node_name': 'node'})
        probes_wires_df = probes_wires_df[['node',
                                        'start_brc',
                                        'end_brc',
                                        'transfer',
                                        'transfer_x_coordinate',
                                        'transfer_y_coordinate',
                                        'probe',
                                        'probe_x_coordinate',
                                        'probe_y_coordinate',
                                        'terminal',
                                        'center',
                                        'side',
                                        'extra_data',
                                        ]]
        probes_wires_df = probes_wires_df.replace({np.nan: None})
        this = probes_wires_df.to_dict('records')
        to_create = []
        for value in this:
            value['fixture'] = instance
            value.pop('extra_data')
            to_create.append(value)
        return to_create

    def convert_fixture(self, instance):
        probes_data = []
        file_path = MEDIA_ROOT / 'wpr_manager' / instance.equipment / 'fixture' / f'{instance.model}_fixture'
        with open(file_path, 'r') as fixture:
            for node_data in self.get_node_data(fixture):
                probe_list = self.get_data(''.join(node_data))
                probes_data.extend(probe_list)
        df = pd.DataFrame(probes_data)
        df.loc[df[4].str.contains('50MIL'), 'measure'] = '50MIL'
        df.loc[df[4].str.contains('75MIL'), 'measure'] = '75MIL'
        df.loc[df[4].str.contains('TOP'), 'position'] = 'TOP'
        df['position'] = df['position'].fillna('BOTTOM')
        df.drop(4, axis=1, inplace=True)
        df.columns = ['node', 'probe', 'x_coordinate', 'y_coordinate', 'center', 'side']
        this = df.to_dict('records')
        to_create = []
        for value in this:
            value['fixture'] = instance
            to_create.append(value)
        return to_create

    def get_node_data(self, iterable: Any):
        """Read a fixture file to create sections based on headers.

        Args:
            iterable (Any): String as line list to parse.

        Yields:
            Iterator[list]: Section as line list.
        """
        section = []
        for line in iterable:
            result = re.search('^    [A-Z]', line)
            if result:
                yield section
                section = []
            section.append(line)

    def get_data(self, node_string: str) -> list:
        """Retrieve full info from section.

        Args:
            node_string (str): section passed as string for regex search.

        Returns:
            list: cleaned data from section.
        """
        data = []
        node = re.search('NODE\s+(?P<node>[\S]+)', node_string)
        try:
            assert not node
        except AssertionError:
            for probe in re.finditer('(?P<probe>P[0-9]+)\s+(?P<x_point>[\S]+),\s+(?P<y_point>[\S]+)(?P<extra_info>[^;]+)', node_string):
                data_to_clean = [value.replace(';','') for value in probe.groupdict().values()]
                data_to_append = [node.group('node'), *data_to_clean]
                data.append(data_to_append)
        return data

    # ==============================================================================
    # WIRELIST CONVERSION
    # ==============================================================================

    def convert_wirelist(self, instance):
        root = MEDIA_ROOT / 'wpr_manager' / instance.equipment / 'wirelist' / f'{instance.model}_wirelist'
        wire_list = []
        with open(root, 'r') as input_file:
            for [test_name, location, section] in self.get_test_section(input_file):
                wires = self.get_wires_from_section(''.join(section))
                for wire in wires:
                    wire.insert(0, test_name)
                    wire.insert(1, location)
                wire_list.extend(wires)
            df = pd.DataFrame(wire_list)
            df.columns = ['test', 'location', 'node', 'brc']
            df = df.sort_values(by='node')
            this = df.to_dict('records')
            to_create = []
            for value in this:
                value['fixture'] = instance
                to_create.append(value)
            return to_create

    def get_test_section(self, iterable):
        """_summary_.

        Args:
            iterable (_type_): _description_

        Yields:
            _type_: _description_
        """
        section = []

        for line in iterable:
            result = re.search("^test\s+(?P<test_name>[a-zA-Z]+)\s+\"(?P<location>[\S]+)\"", line)
            try:
                assert not result
            except AssertionError:
                test_name = result.group('test_name')
                location = result.group('location')
            delimiter = re.search("end test", line)
            try:
                assert not delimiter
            except AssertionError:
                yield [test_name,location,section]
                section = []
            else:
                section.append(line)
        # lines done, yield last
        if section:
            yield [test_name,location,section]

    def get_wires_from_section(self, test_section):
        wires = []
        for wire in re.finditer("wire\s+\"(?P<node>[^\"]+)\"\s+to\s+(?P<brc>[0-9]+)", test_section):
            wires.append(list(wire.groups()))
        return wires


class Processor:

    def create(self, fixture_list, wirelist_list, fixture_2_list):
        with transaction.atomic(using='production'):
            UpgradedPin.objects.bulk_create(UpgradedPin(**value) for value in fixture_2_list)
            Pin.objects.bulk_create(Pin(**value) for value in fixture_list)
            Wire.objects.bulk_create(Wire(**value) for value in wirelist_list)