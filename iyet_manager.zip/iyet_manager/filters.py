import django_filters

from .models import TestedUnit


class TestedUnitFilter(django_filters.FilterSet):

    class Meta:
        model = TestedUnit
        fields = ['general_status', 'model_name', 'family_name', 'ict_name']
