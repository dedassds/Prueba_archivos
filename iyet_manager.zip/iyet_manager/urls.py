from django.urls import include, path

from rest_framework.routers import DefaultRouter

from . import views

app_name = 'iyet_manager'
router = DefaultRouter()
router.register(r"tested_unit", views.TestedUnitViewSet)

urlpatterns = [
    #API touter
    path('API/', include(router.urls)),
    path('dashboard/', views.DashboardView.as_view(), name='dashboard'),
    path('fixtures/create/', views.FixtureCreateView.as_view(), name='create_fixture')
]
